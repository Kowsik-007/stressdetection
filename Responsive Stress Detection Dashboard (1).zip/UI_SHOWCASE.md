# 🎨 UI Showcase - AI Stress Detection Dashboard

## Visual Design Reference Guide

---

## 🎯 Main Dashboard Layout

### Header Section
```
┌────────────────────────────────────────────────────────────┐
│  🧠 AI Stress Detection Dashboard                         │
│  Behavioral pattern analysis powered by machine learning   │
│                                         [🤖 AI Powered]    │
└────────────────────────────────────────────────────────────┘
```

---

## 📊 Circular Stress Meter

### Visual Design:
```
        ╔═══════════════════╗
        ║                   ║
        ║    ┌─────────┐   ║
        ║   ╱           ╲  ║
        ║  │             │ ║
        ║  │             │ ║
        ║  │     45      │ ║  ← Large gradient number
        ║  │  Stress     │ ║
        ║  │   Score     │ ║
        ║  │             │ ║
        ║  │ [Low Stress]│ ║  ← Color-coded badge
        ║   ╲           ╱  ║
        ║    └─────────┘   ║
        ║                   ║
        ╚═══════════════════╝
```

**Features:**
- 280×280px circular gauge
- Animated SVG progress arc
- Gradient number display
- Status badge with gradient background
- Outer glow effect based on severity

**Color Coding:**
- 🟢 0-40: Green gradient (from-emerald-400 to-teal-500)
- 🟡 41-70: Yellow gradient (from-yellow-400 to-orange-500)
- 🔴 71-100: Red gradient (from-red-400 to-pink-500)

---

## 📋 Behavioral Metric Cards

### Card Grid Layout:
```
┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐
│  🌙        │  │  ☕        │  │  📱        │  │  😊        │
│            │  │            │  │            │  │            │
│ Sleep Hrs  │  │ Work Hrs   │  │ Screen Time│  │   Mood     │
│            │  │            │  │            │  │            │
│    7 hrs   │  │    8 hrs   │  │    5 hrs   │  │   😊       │
│            │  │            │  │            │  │            │
└────────────┘  └────────────┘  └────────────┘  └────────────┘
  Blue grad      Purple grad     Teal grad      Orange grad
```

**Card Features:**
- White background with shadow
- Gradient icon container (14×14px)
- Large metric number (4xl)
- Hover effect (shadow-xl)
- Smooth animations

**Gradient Colors:**
- Sleep: `from-blue-400 to-blue-600`
- Work: `from-purple-400 to-purple-600`
- Screen: `from-teal-400 to-emerald-600`
- Mood: `from-orange-400 to-yellow-500`

---

## 📝 Stress Input Form

### Form Layout:
```
┌─────────────────────────────────────────────────────────┐
│  🧠  Update Your Behavioral Data                        │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  Current Mood              Sleep Hours (last night)     │
│  ┌──────────────────┐     ┌──────────────────┐        │
│  │ 😊 Happy       ▼ │     │      7.0          │        │
│  └──────────────────┘     └──────────────────┘        │
│                                                          │
│  Work Hours (today)        Screen Time (today)          │
│  ┌──────────────────┐     ┌──────────────────┐        │
│  │      8.0          │     │      5.0          │        │
│  └──────────────────┘     └──────────────────┘        │
│                                                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │      🧠 Calculate Stress Level                   │  │
│  └──────────────────────────────────────────────────┘  │
│              Gradient button (Teal → Blue)              │
└─────────────────────────────────────────────────────────┘
```

**Input Features:**
- Gradient backgrounds per input type
- Focus ring animation (2px)
- Rounded corners (12px)
- Number inputs with step=0.5
- Emoji-based mood dropdown

**Gradient Inputs:**
- Mood: `from-gray-50 to-blue-50`
- Sleep: `from-gray-50 to-purple-50`
- Work: `from-gray-50 to-teal-50`
- Screen: `from-gray-50 to-orange-50`

---

## 💡 AI Insights Panel

### Panel Design:
```
┌─────────────────────────────────────────────────────────┐
│  🎯 AI-Powered Insights                                 │
│  ┌─────────────────┐  ┌─────────────────┐             │
│  │ Sleep Quality   │  │ Work-Life       │             │
│  │     Good        │  │  Balance        │             │
│  └─────────────────┘  │   Moderate      │             │
│  ┌─────────────────┐  └─────────────────┘             │
│  │ Screen Time     │  ┌─────────────────┐             │
│  │  Status         │  │ Mood Trend      │             │
│  │  ✅ Normal      │  │   Stable        │             │
│  └─────────────────┘  └─────────────────┘             │
│                                                          │
│  Gradient: Blue (#4F8EF7) → Purple (#8B7FE6)           │
└─────────────────────────────────────────────────────────┘
```

**Features:**
- Full-width gradient background
- White text on gradient
- Glassmorphism sub-cards (bg-white/10)
- Grid layout (2 columns)
- Rounded corners (12px)

---

## 📈 Stress Trend Chart

### Chart Design:
```
┌─────────────────────────────────────────────────────────┐
│  📊 Stress Trend Analysis              [Last 7 Days]   │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  100│                                                   │
│   90│                         ╱╲                        │
│   80│                        ╱  ╲                       │
│   70│                   ╱╲  ╱    ╲                      │
│   60│              ╱╲  ╱  ╲╱      ╲                     │
│   50│         ╱╲  ╱  ╲╱             ╲                    │
│   40│    ╱╲  ╱  ╲╱                   ╲                   │
│   30│───╱──╲╱─────────────────────────╲──────────────  │
│   20│                                                   │
│   10│                                                   │
│    0└──────────────────────────────────────────────    │
│      Mon Tue Wed Thu Fri Sat Sun                        │
│                                                          │
│      Blue line with gradient area fill                  │
└─────────────────────────────────────────────────────────┘
```

**Chart Features:**
- Area chart with gradient fill
- Blue line (#4F8EF7)
- Gradient fill (opacity 0.3 → 0)
- Grid lines (stroke-dasharray)
- Interactive tooltips
- Responsive container
- Height: 300px

---

## 🎯 Wellness Recommendations

### Card Grid:
```
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│              │  │              │  │              │
│     🧘       │  │     💧       │  │     🚶       │
│              │  │              │  │              │
│  Meditation  │  │  Hydration   │  │  Movement    │
│              │  │              │  │              │
│ Try 10 min   │  │ Drink 8      │  │ Take breaks  │
│ of mindful-  │  │ glasses of   │  │ every hour   │
│ ness daily   │  │ water/day    │  │ to walk      │
│              │  │              │  │              │
└──────────────┘  └──────────────┘  └──────────────┘
  Emerald grad     Blue-Purple       Orange-Pink
```

**Card Features:**
- Gradient backgrounds with white text
- 3xl emoji icon
- Rounded corners (16px)
- Shadow-xl
- Hover effects

**Gradients:**
- Meditation: `from-emerald-400 to-teal-500`
- Hydration: `from-blue-400 to-purple-500`
- Movement: `from-orange-400 to-pink-500`

---

## 🤖 AI Wellness Chatbot

### Floating Button:
```
                                           ┌────┐
                                           │ AI │← Badge
                                           └────┘
                                              ↓
                                          ┌──────┐
                                          │  💬  │
                                          └──────┘
                                     Gradient circle
                                    (Teal → Blue)
```

### Chat Window:
```
┌──────────────────────────────────────────┐
│  🧠 AI Wellness Assistant   [Online •]  │ ← Gradient header
│                                     [×]   │   (Teal→Blue→Purple)
├──────────────────────────────────────────┤
│                                          │
│  Bot: Hi! I'm your AI wellness...      │ ← Bot message
│       9:00 AM                            │   (Left, white)
│                                          │
│          User: How to reduce stress? │ ← User message
│          9:01 AM                         │   (Right, gradient)
│                                          │
│  ┌────────────────────────────────────┐ │
│  │ ⚠️ High Stress Detected            │ │ ← Alert card
│  │                                    │ │   (Red gradient)
│  │ Stress Level: 85%                  │ │
│  │ ███████████████████░░░░░           │ │
│  │                                    │ │
│  │ 💡 Recommendation:                 │ │
│  │ Take an immediate break...         │ │
│  └────────────────────────────────────┘ │
│                                          │
│  Bot: I noticed your stress levels...  │
│       9:02 AM                            │
│                                          │
├──────────────────────────────────────────┤
│  [Breathing] [Stats] [Sleep] [Stress]  │ ← Quick actions
├──────────────────────────────────────────┤
│  Type your message...           [Send]  │ ← Input area
└──────────────────────────────────────────┘
```

**Chatbot Features:**
- 420×600px window
- Gradient header
- Animated typing indicator (3 dots)
- Color-coded alert cards
- Quick action buttons
- Smooth animations

---

## ⚙️ Settings Page

### Layout:
```
┌─────────────────────────────────────────────────────────┐
│  Settings                                               │
│  Manage your preferences and account settings           │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  👤 Profile                                             │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Name   [John Doe                            ]    │  │
│  │ Email  [john@example.com                    ]    │  │
│  └──────────────────────────────────────────────────┘  │
│                                                          │
│  🔔 Notifications                                       │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Email Notifications         [Toggle ON]          │  │
│  │ Push Notifications          [Toggle OFF]         │  │
│  │ Weekly Reports              [Toggle ON]          │  │
│  │ Stress Alerts               [Toggle ON]          │  │
│  └──────────────────────────────────────────────────┘  │
│                                                          │
│  💾 Data Management                                     │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Data Retention    [30 days ▼]                    │  │
│  │ [Clear All Data]                                  │  │
│  └──────────────────────────────────────────────────┘  │
│                                                          │
│  ℹ️ About                                               │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Version: 1.0.0                                    │  │
│  │ Project: Behavioral Stress Detection             │  │
│  │ Technology: React + Deep Learning                 │  │
│  └──────────────────────────────────────────────────┘  │
│                                                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │           Save Settings                           │  │
│  └──────────────────────────────────────────────────┘  │
│              Gradient button (Blue → Teal)              │
└─────────────────────────────────────────────────────────┘
```

---

## 🔐 Login Page

### Design:
```
        ╔═══════════════════════════════════╗
        ║   Gradient Background             ║
        ║   Blue → Teal → Purple            ║
        ║                                   ║
        ║         ┌─────┐                  ║
        ║         │ 🏥  │ ← Logo           ║
        ║         └─────┘                  ║
        ║   AI Stress Detection            ║
        ║   Behavioral Pattern Analysis     ║
        ║                                   ║
        ║   ┌───────────────────────────┐  ║
        ║   │ [Login]    [Register]    │  ║ ← Toggle
        ║   ├───────────────────────────┤  ║
        ║   │                           │  ║
        ║   │ Email    [              ]│  ║
        ║   │ Password [              ]│  ║
        ║   │                           │  ║
        ║   │ [   Sign In   ]          │  ║ ← Gradient button
        ║   │                           │  ║
        ║   └───────────────────────────┘  ║
        ║                                   ║
        ║   Final Year Project © 2026      ║
        ║                                   ║
        ╚═══════════════════════════════════╝
```

---

## 🎨 Color Reference Card

### Primary Colors:
```
┌──────────────┬──────────────┬──────────────┬──────────────┐
│   #4F8EF7    │   #00C9A7    │   #FF5C5C    │   #8B7FE6    │
│  Primary     │   Accent     │   Alert      │   Purple     │
│  Blue        │   Teal       │   Red        │   Soft       │
└──────────────┴──────────────┴──────────────┴──────────────┘
```

### Background Colors:
```
┌──────────────┬──────────────┬──────────────┐
│   #F5F9FF    │   #FFFFFF    │   #F0F4FF    │
│  Main BG     │   Card BG    │  Alt BG      │
└──────────────┴──────────────┴──────────────┘
```

### Gradient Examples:
```
Button:      #4F8EF7 → #00C9A7
Header BG:   #F5F9FF → #F0F4FF
Insights:    #4F8EF7 → #8B7FE6
Low Stress:  #10B981 → #14B8A6
Med Stress:  #FBBF24 → #FB923C
High Stress: #EF4444 → #EC4899
```

---

## 📐 Spacing & Sizing Guide

### Border Radius:
- Small cards: 12px (rounded-xl)
- Large cards: 16px (rounded-2xl)
- Buttons: 12px (rounded-xl)
- Inputs: 12px (rounded-xl)
- Pills: 9999px (rounded-full)

### Shadows:
- Default card: shadow-lg
- Hover card: shadow-xl
- Button: shadow-lg
- Chat widget: shadow-2xl

### Padding:
- Card content: 24px (p-6)
- Small cards: 16px (p-4)
- Buttons: 16px/24px (px-4 py-3)
- Page container: 24px (p-6)

### Font Sizes:
- Page title: 30px (text-3xl)
- Section heading: 20px (text-xl)
- Card title: 16px (text-base)
- Body text: 14px (text-sm)
- Metric numbers: 36px (text-4xl)

---

## 🎬 Animation Timings

### Duration:
- Fast: 0.3s (hover, focus)
- Medium: 0.5s (fade-in)
- Slow: 1-2s (progress bars, charts)

### Easing:
- Default: ease-in-out
- Spring: damping=25, stiffness=300
- Progress: ease-out

### Delays:
- Staggered cards: 0.1s increments
- Sequential content: 0.2s increments

---

## 📱 Responsive Breakpoints

```
Mobile:    < 640px    (1 column, stacked layout)
Tablet:    640-1024px (2 columns, compact sidebar)
Desktop:   > 1024px   (Full layout, fixed sidebar)
```

### Responsive Changes:
- Sidebar: Fixed on desktop, drawer on mobile
- Card grid: 4→2→1 columns
- Form: 2→1 columns
- Chart: Full width responsive
- Chatbot: 420px → calc(100vw - 32px)

---

## ✨ Micro-Interactions

1. **Button Hover**: Scale 1.02, shadow increase
2. **Card Hover**: Shadow elevation
3. **Input Focus**: Ring animation (2px blue)
4. **Toggle Switch**: Slide animation (0.3s)
5. **Meter Fill**: Circular progress (2s)
6. **Number Count**: Smooth transition
7. **Alert Appear**: Fade + slide up
8. **Typing Dots**: Bounce animation

---

## 🎯 Accessibility Features

- ✅ Color contrast ratio > 4.5:1
- ✅ Focus indicators on all interactive elements
- ✅ Semantic HTML structure
- ✅ ARIA labels where needed
- ✅ Keyboard navigation support
- ✅ Screen reader friendly
- ✅ Touch-friendly button sizes (44×44px minimum)

---

**UI Design Version:** 2.0.0  
**Design System:** Healthcare SaaS  
**Status:** ✅ Complete & Production Ready
