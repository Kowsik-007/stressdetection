# 🚀 Quick Start Guide

Get your Stress Detection System up and running in 5 minutes!

## ⚡ Step 1: Installation

```bash
# Clone or download the project
cd stress-detection-system

# Install dependencies
npm install
# or
pnpm install
```

## 🎯 Step 2: Run the Application

```bash
npm run dev
# or
pnpm dev
```

The app will open at `http://localhost:5173`

## 🔐 Step 3: Login

Use any email/password to login (mock authentication):
- Email: `demo@example.com`
- Password: `password123`

Or register a new account!

## 📊 Step 4: Explore Features

### Dashboard
- View live sensor data (Heart Rate, GSR, Temperature)
- Monitor stress levels in real-time
- Check interactive charts

### History
- View 7-day stress trends
- Download CSV reports
- Analyze patterns

### Alerts
- Check health notifications
- Get wellness recommendations
- Take action on high-stress alerts

### AI Chatbot
- Click the floating AI button (bottom-right)
- Get real-time stress alerts in chat
- Ask wellness questions
- Try quick actions: Breathing Exercise, View Stats, Sleep Tips
- See animated typing indicator

## 🔧 Configuration (Optional)

### Connect to Your Backend API

1. **Edit API Configuration:**
   ```typescript
   // File: /src/app/services/api.ts
   const API_BASE_URL = "http://your-backend-url:8000/api";
   ```

2. **Or use Environment Config:**
   ```typescript
   // File: /src/app/config/environment.ts
   const development: Config = {
     apiBaseUrl: "http://localhost:8000/api",
     enableMockData: false, // Disable mock data
   };
   ```

3. **Update Component Files:**
   - `/src/app/pages/Login.tsx`
   - `/src/app/pages/Dashboard.tsx`
   - `/src/app/pages/History.tsx`
   
   Uncomment the API calls and remove mock data generation.

## 🎨 Customization

### Change Theme Colors

Edit `/src/styles/theme.css`:
```css
:root {
  --color-primary: #14b8a6; /* Teal */
  --color-secondary: #3b82f6; /* Blue */
}
```

### Adjust Refresh Rate

Edit `/src/app/config/environment.ts`:
```typescript
autoRefreshInterval: 3000, // Change from 5000 to 3000 (3 seconds)
```

## 📱 Features Overview

| Feature | Description | Status |
|---------|-------------|--------|
| Authentication | Login/Register | ✅ Ready |
| Dashboard | Real-time monitoring | ✅ Ready |
| Charts | Live data visualization | ✅ Ready |
| History | 7-day trends | ✅ Ready |
| Alerts | Notifications | ✅ Ready |
| AI Chatbot | Wellness assistant | ✅ Ready |
| Dark Mode | Theme toggle | ✅ Ready |
| Responsive | Mobile-friendly | ✅ Ready |
| API Integration | Backend connection | ⚙️ Configure |

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Kill the process on port 5173
npx kill-port 5173

# Or specify a different port
npm run dev -- --port 3000
```

### Dependencies Error
```bash
# Clear node_modules and reinstall
rm -rf node_modules
npm install
```

### Build Error
```bash
# Clear cache and rebuild
rm -rf dist
npm run build
```

## 📖 Next Steps

1. ✅ Run the application
2. ✅ Explore all features
3. 📖 Read [README.md](/README.md) for detailed documentation
4. 🔗 Check [API_INTEGRATION_GUIDE.md](/API_INTEGRATION_GUIDE.md) for backend setup
5. 🎨 Customize the theme and branding
6. 🚀 Deploy to production

## 🌐 Deployment

### Build for Production
```bash
npm run build
```

The built files will be in the `/dist` folder.

### Deploy Options
- **Vercel:** `vercel deploy`
- **Netlify:** Drag & drop `/dist` folder
- **GitHub Pages:** Push to `gh-pages` branch
- **Your Server:** Upload `/dist` folder to web server

## 💡 Pro Tips

- **Dark Mode:** Toggle with the moon/sun icon in the navbar
- **Download Reports:** Use the "Download Report" button in History page
- **Filter Alerts:** Click filter buttons to view specific priority alerts
- **Real-time Updates:** Dashboard auto-refreshes every 5 seconds
- **AI Chatbot:** Click the floating AI button for instant wellness support
- **Quick Actions:** Use chatbot quick action buttons for common tasks

## 🆘 Need Help?

- Check the console for errors (F12 in browser)
- Verify all dependencies are installed
- Ensure you're using Node.js 18+ 
- Read the full documentation in README.md

## 🎉 Success!

You're all set! Your stress detection system is now running. Start monitoring health data and detecting stress patterns.

---

**Built for Final Year Engineering Project**  
**Technology Stack:** React + Tailwind CSS + Recharts + Axios