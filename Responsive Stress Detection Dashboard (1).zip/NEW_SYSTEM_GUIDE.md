# 🧠 AI-Powered Behavioral Stress Detection System

## Overview

This is a **modern, clean, AI-powered stress detection dashboard** that estimates stress levels using **behavioral inputs** instead of hardware sensors. The system analyzes patterns in sleep, mood, work hours, and screen time to predict stress levels using machine learning.

## 🎨 Design Philosophy

### Visual Style
- **Calming Healthcare Aesthetic**: Professional medical-tech interface
- **Futuristic & Clean**: Minimal layout with rounded cards
- **Soft Shadows & Glassmorphism**: Modern elevation effects
- **Smooth Animations**: Motion-based transitions for engagement

### Color Palette

```css
Primary Blue:   #4F8EF7
Accent Teal:    #00C9A7
Alert Red:      #FF5C5C
Background:     #F5F9FF
Soft Purple:    #8B7FE6
Warning Yellow: #FFA94D
```

### Typography
- **Font Family**: Clean sans-serif (system default)
- **Rounded Corners**: 12-24px border radius
- **Consistent Spacing**: 4px grid system

---

## 🏗️ System Architecture

### Input-Based Stress Calculation

Unlike traditional sensor-based systems, this uses **behavioral pattern analysis**:

#### Input Parameters:
1. **Sleep Hours** (0-24h)
   - Optimal range: 7-9 hours
   - Impact: 0-30 stress points

2. **Work Hours** (0-24h)
   - Optimal range: ≤8 hours
   - Impact: 0-30 stress points

3. **Screen Time** (0-24h)
   - Optimal range: <6 hours
   - Impact: 0-20 stress points

4. **Mood Level**
   - Options: Happy, Neutral, Anxious, Tired
   - Impact: 0-20 stress points

#### Stress Score Calculation:

```javascript
baseScore = 0

// Sleep Factor (0-30 points)
if (sleepHours < 6) baseScore += 25
else if (sleepHours < 7) baseScore += 15
else if (sleepHours > 9) baseScore += 10

// Work Hours Factor (0-30 points)
if (workHours > 10) baseScore += 30
else if (workHours > 8) baseScore += 20
else if (workHours < 4) baseScore += 15

// Screen Time Factor (0-20 points)
if (screenTime > 8) baseScore += 20
else if (screenTime > 6) baseScore += 12

// Mood Factor (0-20 points)
moodScores = {
  Happy: 0,
  Neutral: 10,
  Anxious: 20,
  Tired: 15
}
baseScore += moodScores[mood]

finalScore = min(100, max(0, baseScore))
```

#### Stress Level Classification:

| Score Range | Level | Color | Status |
|-------------|-------|-------|--------|
| 0-40 | Low | Green (#00C9A7) | Healthy |
| 41-70 | Medium | Yellow (#FFA94D) | Moderate |
| 71-100 | High | Red (#FF5C5C) | Alert |

---

## 📱 Main Features

### 1. **Large Circular Stress Meter**
- **Size**: 280x280px
- **Scale**: 0-100
- **Animation**: Smooth circular progress with gradient
- **Status Badge**: Color-coded (Low/Medium/High)
- **Visual Elements**:
  - Animated SVG circle
  - Gradient text display
  - Glow effect based on severity
  - Real-time score update

### 2. **Behavioral Metric Cards**
Four beautifully designed cards showing:
- 🌙 **Sleep Hours** (Blue gradient)
- ☕ **Work Hours** (Purple gradient)
- 📱 **Screen Time** (Teal gradient)
- 😊 **Mood** (Orange gradient)

Each card features:
- Icon in gradient background
- Large metric number
- Smooth hover animations

### 3. **Stress Input Form**
Clean, modern form with:
- **Mood Dropdown**: 4 emoji-based options
- **Numeric Inputs**: Sleep, work, screen time
- **Gradient Backgrounds**: Each input has themed gradient
- **Submit Button**: AI-powered calculation trigger

Form Validation:
- All fields required
- Numeric validation (0-24 range)
- Real-time updates

### 4. **AI-Powered Insights Panel**
Gradient card displaying:
- Sleep Quality Assessment
- Work-Life Balance Status
- Screen Time Warning (if high)
- Mood Trend Analysis

### 5. **Stress Trend Chart**
Beautiful area chart showing:
- Last 7 days of stress data
- Smooth gradient fill
- Interactive tooltips
- Responsive design

### 6. **AI Wellness Recommendations**
Three colorful cards with:
- 🧘 Meditation suggestions
- 💧 Hydration reminders
- 🚶 Movement tips

---

## 🗂️ Navigation Structure

### Sidebar Menu (Left Vertical)
1. **Dashboard** - Main stress monitoring
2. **Stress Analysis** - Historical data & trends
3. **AI Wellness Assistant** - Chatbot notifications
4. **Settings** - User preferences

### Top Header
- App logo & title
- User profile
- Dark mode toggle (Moon/Sun icon)
- Notification bell
- Logout button

---

## 🤖 AI Wellness Assistant

### Floating Chatbot Widget
- **Position**: Bottom-right corner
- **Size**: 420×600px
- **Trigger**: Floating AI button

### Features:
1. **Real-Time Stress Alerts**
   - Automatic notifications when stress ≥60%
   - Color-coded alert cards
   - Stress percentage with progress bar
   - Personalized recommendations

2. **Animated Typing Indicator**
   - Three bouncing dots
   - Smooth fade animations
   - Realistic bot "thinking" effect

3. **Smart Conversation**
   - Context-aware responses
   - Wellness advice
   - Breathing exercises
   - Sleep tips
   - Data analysis

4. **Quick Action Buttons**
   - Breathing Exercise
   - View Stats
   - Sleep Tips
   - Stress Help

5. **Gradient UI**
   - Header: Teal → Blue → Purple
   - User messages: Teal → Blue
   - Bot avatar: Teal → Blue gradient circle

---

## 🎨 UI Components Breakdown

### Dashboard Layout

```
┌─────────────────────────────────────────────────────────┐
│  Header: AI Stress Detection Dashboard                  │
│  Subtitle: Behavioral pattern analysis                  │
└─────────────────────────────────────────────────────────┘
                    ↓
┌──────────────┐  ┌─────────────────────────────────────┐
│              │  │  Behavioral Metrics (4 cards)       │
│   Circular   │  │  [Sleep] [Work] [Screen] [Mood]     │
│   Stress     │  │                                      │
│   Meter      │  │  ───────────────────────────────────│
│   (0-100)    │  │  Input Form                          │
│              │  │  • Mood Dropdown                     │
│   Status:    │  │  • Sleep Hours Input                 │
│   Low/Med    │  │  • Work Hours Input                  │
│   /High      │  │  • Screen Time Input                 │
│              │  │  [Calculate Stress Button]           │
└──────────────┘  │                                      │
                  │  ───────────────────────────────────│
                  │  AI Insights (Gradient card)         │
                  └─────────────────────────────────────┘
                                ↓
        ┌──────────────────────────────────────┐
        │  Stress Trend Chart (Last 7 Days)    │
        │  [Area Chart with Gradient Fill]     │
        └──────────────────────────────────────┘
                                ↓
        ┌──────────────────────────────────────┐
        │  Recommendations (3 colorful cards)  │
        │  [Meditation] [Hydration] [Movement] │
        └──────────────────────────────────────┘
```

### Color-Coded System

#### Status Indicators:
- **Low Stress** (0-40): Green gradient, calm messaging
- **Medium Stress** (41-70): Yellow/orange, moderate concern
- **High Stress** (71-100): Red gradient, urgent alerts

#### Gradient Combinations:
```css
/* Primary Button */
background: linear-gradient(to right, #4F8EF7, #00C9A7);

/* Dashboard Header */
background: linear-gradient(to bottom right, #F5F9FF, #F0F4FF);

/* Insight Panel */
background: linear-gradient(to bottom right, #4F8EF7, #8B7FE6);

/* Metric Cards */
Sleep:  linear-gradient(to bottom right, #60A5FA, #3B82F6);
Work:   linear-gradient(to bottom right, #A78BFA, #8B5CF6);
Screen: linear-gradient(to bottom right, #34D399, #10B981);
Mood:   linear-gradient(to bottom right, #FB923C, #FBBF24);
```

---

## 🔧 Technical Implementation

### Tech Stack
- **Framework**: React 18.3.1
- **Routing**: React Router 7.13.0
- **Styling**: Tailwind CSS 4.1.12
- **Charts**: Recharts 2.15.2
- **Icons**: Lucide React 0.487.0
- **Animations**: Motion 12.23.24
- **HTTP**: Axios 1.13.5

### Key Components

```
/src/app/
├── components/
│   ├── StressMeter.tsx        # Circular stress gauge
│   ├── WellnessChatbot.tsx    # AI chat widget
│   ├── ChatbotTrigger.tsx     # Event emitter
│   └── Layout.tsx             # Main layout wrapper
├── pages/
│   ├── Dashboard.tsx          # Main dashboard
│   ├── History.tsx            # Stress analysis
│   ├── Alerts.tsx             # AI wellness
│   ├── Settings.tsx           # User settings
│   └── Login.tsx              # Authentication
└── routes.ts                  # App routing
```

### State Management

```typescript
// Dashboard State
const [stressScore, setStressScore] = useState(45);
const [formData, setFormData] = useState({
  sleepHours: 7,
  workHours: 8,
  screenTime: 5,
  mood: "Neutral"
});
const [insights, setInsights] = useState({
  sleepQuality: "Good",
  workBalance: "Moderate",
  screenWarning: false,
  moodTrend: "Stable"
});
```

---

## 🚀 Getting Started

### Installation

```bash
npm install
# or
pnpm install
```

### Run Development Server

```bash
npm run dev
# Opens at http://localhost:5173
```

### Login

Use any credentials (mock authentication):
```
Email: demo@example.com
Password: password123
```

---

## 💡 How to Use

### Step 1: Input Your Behavioral Data
1. Navigate to Dashboard
2. Fill in the behavioral input form:
   - Select your current mood
   - Enter hours of sleep (last night)
   - Enter work hours (today)
   - Enter screen time (today)

### Step 2: Calculate Stress
1. Click "Calculate Stress Level" button
2. Watch the AI analyze your inputs
3. View your stress score on the circular meter

### Step 3: Review Insights
1. Check the AI-powered insights panel
2. Review sleep quality, work balance, screen status
3. See your mood trend analysis

### Step 4: Interact with AI Assistant
1. Click the floating AI button (bottom-right)
2. Ask questions about stress management
3. Get personalized wellness recommendations
4. Try quick actions for breathing exercises

### Step 5: Track Trends
1. View the 7-day stress trend chart
2. Monitor patterns over time
3. Adjust behaviors based on data

---

## 🎯 Backend Integration (Optional)

### API Endpoints

```typescript
// Calculate stress from behavioral data
POST /api/calculate-stress
Body: {
  sleepHours: number,
  workHours: number,
  screenTime: number,
  mood: string
}
Response: {
  stressScore: number,
  insights: {
    sleepQuality: string,
    workBalance: string,
    recommendations: string[]
  }
}

// Get historical stress data
GET /api/stress-history?days=7
Response: {
  data: [
    { score: number, timestamp: string }
  ]
}
```

### Machine Learning Integration

The system is designed to work with:
- **Deep Learning Models**: LSTM, GRU for pattern recognition
- **Feature Engineering**: Sleep quality, work-life balance metrics
- **Prediction API**: RESTful endpoint for stress prediction

Example ML Model Input:
```python
features = [
    sleep_hours,        # 7.5
    work_hours,         # 8.0
    screen_time,        # 5.0
    mood_encoded,       # 2 (0=Happy, 1=Neutral, 2=Anxious, 3=Tired)
    day_of_week,        # 5 (Friday)
    previous_stress     # 42
]

stress_prediction = model.predict([features])
```

---

## 📊 Data Privacy & Security

### Local Storage
- User credentials (mock - not production ready)
- Behavioral data history
- App settings & preferences

### No Hardware Dependencies
- ✅ No IoT sensors required
- ✅ No wearable devices needed
- ✅ Privacy-friendly (user inputs only)
- ✅ Completely offline capable

---

## 🎓 Project Information

### Final Year Engineering Project
**Title**: Behavioral Pattern-Based Early Stress & Burnout Detection System Using Deep Learning

**Key Objectives**:
1. Analyze behavioral patterns (not physical sensors)
2. Predict stress levels using AI/ML
3. Provide actionable wellness recommendations
4. Modern, user-friendly healthcare interface

**Technologies Used**:
- Frontend: React, Tailwind CSS, Motion
- Data Viz: Recharts
- AI/ML: Deep Learning (backend integration ready)
- Design: Healthcare SaaS aesthetic

---

## 🌟 Key Differentiators

### vs. Traditional Sensor-Based Systems:

| Feature | This System | Sensor-Based |
|---------|-------------|--------------|
| Hardware | ❌ None required | ✅ IoT sensors needed |
| Cost | 💰 Free | 💰💰 Expensive |
| Privacy | 🔒 High (manual input) | ⚠️ Continuous monitoring |
| Accessibility | 🌍 Universal | 📍 Location-dependent |
| Data Type | Behavioral patterns | Physiological signals |
| ML Model | Behavioral analysis | Signal processing |

---

## 🔮 Future Enhancements

1. **Advanced ML Models**
   - LSTM for time-series prediction
   - Multi-modal behavioral analysis
   - Personalized stress thresholds

2. **Enhanced AI Assistant**
   - Voice input/output
   - Natural language processing
   - Sentiment analysis

3. **Social Features**
   - Anonymous community support
   - Shared wellness challenges
   - Group meditation sessions

4. **Integrations**
   - Calendar sync (auto-detect work hours)
   - Screen time apps (auto-import data)
   - Sleep tracking apps

5. **Analytics**
   - Weekly/monthly reports
   - Downloadable PDFs
   - Stress pattern insights

---

## 📝 License

Final Year Engineering Project - Educational Use

---

**Built with 💙 for better mental health through AI**
