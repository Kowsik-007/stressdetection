import axios from "axios";

// Configure your API base URL here
const API_BASE_URL = "http://your-api-url"; // Replace with your actual API URL

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Authentication APIs
export const login = async (email: string, password: string) => {
  try {
    const response = await api.post("/login", { email, password });
    return response.data;
  } catch (error) {
    console.error("Login error:", error);
    throw error;
  }
};

export const register = async (name: string, email: string, password: string) => {
  try {
    const response = await api.post("/register", { name, email, password });
    return response.data;
  } catch (error) {
    console.error("Register error:", error);
    throw error;
  }
};

// Sensor Data API
export const sendSensorData = async (
  userId: string,
  heartRate: number,
  gsr: number,
  temperature: number
) => {
  try {
    const response = await api.post("/sensor-data", {
      userId,
      heartRate,
      gsr,
      temperature,
    });
    return response.data;
  } catch (error) {
    console.error("Send sensor data error:", error);
    throw error;
  }
};

// Prediction API
export const getStressPrediction = async (userId: string) => {
  try {
    const response = await api.get(`/predict/${userId}`);
    return response.data;
  } catch (error) {
    console.error("Get prediction error:", error);
    throw error;
  }
};

// History API
export const getHistory = async (userId: string) => {
  try {
    const response = await api.get(`/history/${userId}`);
    return response.data;
  } catch (error) {
    console.error("Get history error:", error);
    throw error;
  }
};

// Add authorization token to requests if available
api.interceptors.request.use((config) => {
  const user = localStorage.getItem("user");
  if (user) {
    const userData = JSON.parse(user);
    if (userData.token) {
      config.headers.Authorization = `Bearer ${userData.token}`;
    }
  }
  return config;
});

export default api;
