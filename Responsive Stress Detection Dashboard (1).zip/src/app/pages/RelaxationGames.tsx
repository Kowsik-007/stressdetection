import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Gamepad2, 
  Wind, 
  Palette, 
  Brain, 
  Sparkles, 
  Heart,
  Circle,
  Square,
  Triangle,
  Star,
  Play,
  Pause,
  RotateCcw,
  Award,
  Trophy,
  Timer,
  TrendingUp,
  Activity,
  Target,
  Zap,
  Smile,
  Check,
  ChevronRight
} from "lucide-react";

export function RelaxationGames() {
  const [activeGame, setActiveGame] = useState<string | null>(null);
  const [totalPlayTime, setTotalPlayTime] = useState(0);
  const [gamesCompleted, setGamesCompleted] = useState(0);
  const [wellnessScore, setWellnessScore] = useState(72);

  const games = [
    {
      id: "breathing",
      title: "Breathing Circle",
      description: "Guided breathing exercises to reduce anxiety and improve focus",
      icon: Wind,
      color: "from-blue-400 via-blue-500 to-cyan-500",
      bgColor: "from-blue-50/80 via-cyan-50/60 to-blue-50/80",
      benefit: "Reduces anxiety by 40%",
      duration: "5 min"
    },
    {
      id: "color-match",
      title: "Color Harmony",
      description: "Match calming colors to enhance visual processing and mindfulness",
      icon: Palette,
      color: "from-purple-400 via-pink-400 to-fuchsia-500",
      bgColor: "from-purple-50/80 via-pink-50/60 to-purple-50/80",
      benefit: "Improves focus by 35%",
      duration: "3 min"
    },
    {
      id: "memory",
      title: "Mindful Memory",
      description: "Strengthen cognitive function through pattern recognition",
      icon: Brain,
      color: "from-teal-400 via-emerald-400 to-green-500",
      bgColor: "from-teal-50/80 via-emerald-50/60 to-teal-50/80",
      benefit: "Enhances memory by 28%",
      duration: "4 min"
    },
    {
      id: "zen-draw",
      title: "Zen Drawing",
      description: "Free-form creative expression for stress relief and relaxation",
      icon: Sparkles,
      color: "from-indigo-400 via-violet-400 to-purple-500",
      bgColor: "from-indigo-50/80 via-violet-50/60 to-indigo-50/80",
      benefit: "Reduces stress by 45%",
      duration: "Open"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5F9FF] via-[#F0F4FF] to-[#E8F5FF] relative overflow-hidden">
      {/* Ambient Background Effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-200/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-200/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-teal-200/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto p-6 space-y-8">
        {/* Header Section */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center space-y-4"
        >
          <div className="flex items-center justify-center gap-4 mb-2">
            <motion.div 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 15 }}
              className="relative"
            >
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-purple-500 via-blue-500 to-teal-500 flex items-center justify-center shadow-2xl">
                <Gamepad2 className="w-9 h-9 text-white" />
              </div>
              <div className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full border-2 border-white flex items-center justify-center">
                <Zap className="w-3 h-3 text-white" />
              </div>
            </motion.div>
            <div className="text-left">
              <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-600 via-blue-600 to-teal-600 bg-clip-text text-transparent">
                Relaxation Games Zone
              </h1>
              <div className="flex items-center gap-2 mt-1">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-sm text-gray-600 font-medium">AI-Powered Wellness Activities</span>
              </div>
            </div>
          </div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Evidence-based interactive experiences designed to reduce stress, enhance cognitive function, 
            and promote mental wellness through therapeutic gameplay
          </p>
        </motion.div>

        {/* Wellness Dashboard - Only show when no game active */}
        {activeGame === null && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid md:grid-cols-3 gap-4"
          >
            {/* Wellness Score */}
            <div className="bg-white/70 backdrop-blur-xl rounded-2xl p-6 shadow-lg border border-white/50 hover:shadow-xl transition-all">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center shadow-lg">
                    <Activity className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500 font-medium">Wellness Score</div>
                    <div className="text-3xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                      {wellnessScore}%
                    </div>
                  </div>
                </div>
                <TrendingUp className="w-5 h-5 text-green-500" />
              </div>
              <div className="relative h-2 bg-gray-200 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${wellnessScore}%` }}
                  transition={{ duration: 1, delay: 0.3 }}
                  className="absolute top-0 left-0 h-full bg-gradient-to-r from-green-400 to-emerald-500 rounded-full"
                />
              </div>
            </div>

            {/* Play Time */}
            <div className="bg-white/70 backdrop-blur-xl rounded-2xl p-6 shadow-lg border border-white/50 hover:shadow-xl transition-all">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-400 to-cyan-500 flex items-center justify-center shadow-lg">
                    <Timer className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500 font-medium">Total Play Time</div>
                    <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                      {totalPlayTime}m
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-xs text-gray-500">This week</div>
            </div>

            {/* Games Completed */}
            <div className="bg-white/70 backdrop-blur-xl rounded-2xl p-6 shadow-lg border border-white/50 hover:shadow-xl transition-all">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center shadow-lg">
                    <Trophy className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500 font-medium">Sessions</div>
                    <div className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                      {gamesCompleted}
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-xs text-gray-500">Completed this week</div>
            </div>
          </motion.div>
        )}

        {activeGame === null ? (
          /* Games Grid */
          <div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="mb-4 flex items-center justify-between"
            >
              <h2 className="text-2xl font-semibold text-gray-800">Available Activities</h2>
              <div className="px-4 py-2 bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-200 rounded-full text-sm text-gray-700 font-medium">
                {games.length} Therapeutic Games
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="grid md:grid-cols-2 gap-6"
            >
              {games.map((game, index) => {
                const Icon = game.icon;
                return (
                  <motion.div
                    key={game.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 * index, duration: 0.5 }}
                    whileHover={{ y: -8, transition: { duration: 0.2 } }}
                    onClick={() => setActiveGame(game.id)}
                    className="group relative overflow-hidden bg-white/70 backdrop-blur-xl rounded-3xl cursor-pointer border border-white/50 shadow-lg hover:shadow-2xl transition-all duration-300"
                  >
                    {/* Gradient Background */}
                    <div className={`absolute inset-0 bg-gradient-to-br ${game.bgColor} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
                    
                    {/* Decorative Elements */}
                    <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br opacity-5 rounded-full blur-3xl group-hover:opacity-10 transition-opacity" 
                         style={{ background: `linear-gradient(to bottom right, var(--tw-gradient-stops))` }} />
                    
                    <div className="relative z-10 p-8">
                      <div className="flex items-start justify-between mb-6">
                        <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${game.color} flex items-center justify-center shadow-xl group-hover:scale-110 group-hover:rotate-6 transition-all duration-300`}>
                          <Icon className="w-8 h-8 text-white" />
                        </div>
                        
                        <div className="flex flex-col gap-2 items-end">
                          <div className="px-3 py-1 bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 rounded-full text-xs font-semibold">
                            {game.benefit}
                          </div>
                          <div className="px-3 py-1 bg-gradient-to-r from-blue-100 to-cyan-100 text-blue-700 rounded-full text-xs font-semibold flex items-center gap-1">
                            <Timer className="w-3 h-3" />
                            {game.duration}
                          </div>
                        </div>
                      </div>
                      
                      <h3 className="text-2xl font-bold text-gray-800 mb-3 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text" 
                          style={{ backgroundImage: `linear-gradient(to right, var(--tw-gradient-stops))`, backgroundClip: 'text' }}>
                        {game.title}
                      </h3>
                      <p className="text-gray-600 mb-6 leading-relaxed">
                        {game.description}
                      </p>
                      
                      <button className={`w-full flex items-center justify-center gap-2 px-6 py-4 bg-gradient-to-r ${game.color} text-white rounded-xl font-semibold shadow-lg group-hover:shadow-xl transition-all group-hover:scale-105`}>
                        <Play className="w-5 h-5" />
                        Begin Session
                        <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>

                    {/* Shimmer Effect */}
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>
        ) : (
          /* Active Game Display */
          <div>
            <motion.button
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              onClick={() => setActiveGame(null)}
              className="mb-6 flex items-center gap-2 px-5 py-3 bg-white/70 backdrop-blur-xl rounded-xl shadow-lg hover:shadow-xl transition-all text-gray-700 font-medium border border-white/50"
            >
              ← End Session
            </motion.button>

            {activeGame === "breathing" && <BreathingGame />}
            {activeGame === "color-match" && <ColorMatchGame />}
            {activeGame === "memory" && <MemoryGame />}
            {activeGame === "zen-draw" && <ZenDrawGame />}
          </div>
        )}

        {/* Benefits & Research Section - Only show when no game active */}
        {activeGame === null && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 rounded-3xl p-8 md:p-10 text-white shadow-2xl relative overflow-hidden"
          >
            {/* Decorative Background */}
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDEzNGgxMnYxMkgzNnptLTI0LTI0aDEydjEySDF6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-20" />
            
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center">
                  <Heart className="w-7 h-7 text-white" />
                </div>
                <h2 className="text-3xl font-bold">Why Relaxation Games Matter</h2>
              </div>
              
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-emerald-500 rounded-lg flex items-center justify-center">
                      <Check className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold">Reduce Stress</h3>
                  </div>
                  <p className="text-white/90 leading-relaxed">
                    Clinical studies show 40% reduction in cortisol levels through regular mindful gaming activities
                  </p>
                </div>

                <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-cyan-500 rounded-lg flex items-center justify-center">
                      <Target className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold">Improve Focus</h3>
                  </div>
                  <p className="text-white/90 leading-relaxed">
                    Enhanced concentration and cognitive performance through therapeutic pattern recognition
                  </p>
                </div>

                <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-500 rounded-lg flex items-center justify-center">
                      <Smile className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold">Promote Calm</h3>
                  </div>
                  <p className="text-white/90 leading-relaxed">
                    Activate natural relaxation response and improve overall emotional well-being
                  </p>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-5 border border-white/20">
                <div className="flex items-start gap-3">
                  <Brain className="w-6 h-6 text-white flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Evidence-Based Approach</h4>
                    <p className="text-sm text-white/90">
                      Our relaxation games are designed based on cognitive behavioral therapy (CBT) principles and 
                      neuroscience research to maximize stress relief and mental wellness benefits.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

/* Breathing Exercise Game */
function BreathingGame() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [phase, setPhase] = useState<"inhale" | "hold" | "exhale">("inhale");
  const [count, setCount] = useState(4);
  const [sessionsCompleted, setSessionsCompleted] = useState(0);
  const [totalTime, setTotalTime] = useState(0);

  useEffect(() => {
    if (!isPlaying) return;

    const timer = setInterval(() => {
      setTotalTime((t) => t + 1);
      setCount((prev) => {
        if (prev > 1) return prev - 1;

        // Move to next phase
        if (phase === "inhale") {
          setPhase("hold");
          return 4;
        } else if (phase === "hold") {
          setPhase("exhale");
          return 4;
        } else {
          setPhase("inhale");
          setSessionsCompleted((s) => s + 1);
          return 4;
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isPlaying, phase]);

  const getScale = () => {
    if (phase === "inhale") return 1.8;
    if (phase === "hold") return 1.8;
    return 1;
  };

  const getGradient = () => {
    if (phase === "inhale") return "from-blue-400 via-cyan-400 to-teal-400";
    if (phase === "hold") return "from-purple-400 via-violet-400 to-indigo-400";
    return "from-pink-400 via-rose-400 to-red-400";
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-white/70 backdrop-blur-xl rounded-3xl p-8 md:p-12 shadow-2xl border border-white/50"
    >
      <div className="text-center space-y-8">
        {/* Header */}
        <div>
          <div className="flex items-center justify-center gap-3 mb-3">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center shadow-lg">
              <Wind className="w-7 h-7 text-white" />
            </div>
            <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
              Breathing Circle
            </h2>
          </div>
          <p className="text-gray-600 text-lg">Guided 4-4-4 breathing technique for stress relief</p>
        </div>

        {/* Stats Bar */}
        <div className="flex items-center justify-center gap-4">
          <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-2xl px-6 py-3 shadow-md border border-blue-100">
            <div className="text-sm text-gray-600 font-medium">Cycles</div>
            <div className="text-3xl font-bold text-blue-600">{sessionsCompleted}</div>
          </div>
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl px-6 py-3 shadow-md border border-purple-100">
            <div className="text-sm text-gray-600 font-medium">Time</div>
            <div className="text-3xl font-bold text-purple-600">{Math.floor(totalTime / 60)}:{(totalTime % 60).toString().padStart(2, '0')}</div>
          </div>
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl px-6 py-3 shadow-md border border-green-100">
            <div className="text-sm text-gray-600 font-medium">Stress Relief</div>
            <div className="text-3xl font-bold text-green-600">{Math.min(95, sessionsCompleted * 8)}%</div>
          </div>
        </div>

        {/* Breathing Circle */}
        <div className="flex items-center justify-center h-[450px] relative">
          {/* Outer Glow Rings */}
          <motion.div
            animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.1, 0.3] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className={`absolute w-96 h-96 rounded-full bg-gradient-to-br ${getGradient()} opacity-20 blur-2xl`}
          />
          
          <motion.div
            animate={{ scale: getScale() }}
            transition={{ duration: 4, ease: "easeInOut" }}
            className="relative"
          >
            <div className={`w-80 h-80 rounded-full bg-gradient-to-br ${getGradient()} shadow-2xl flex items-center justify-center relative overflow-hidden`}>
              {/* Inner Glow */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent" />
              
              {/* Content */}
              <div className="text-center text-white relative z-10">
                <motion.div 
                  key={count}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="text-8xl font-bold mb-4 drop-shadow-lg"
                >
                  {count}
                </motion.div>
                <div className="text-2xl font-semibold uppercase tracking-widest">
                  {phase}
                </div>
                <div className="text-sm mt-2 text-white/80">
                  {phase === "inhale" ? "Breathe in slowly" : phase === "hold" ? "Hold your breath" : "Breathe out slowly"}
                </div>
              </div>
            </div>

            {/* Particle Effects */}
            {isPlaying && (
              <>
                {[...Array(8)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-3 h-3 bg-white/40 rounded-full"
                    style={{
                      top: '50%',
                      left: '50%',
                    }}
                    animate={{
                      x: [0, Math.cos(i * 45 * Math.PI / 180) * 180],
                      y: [0, Math.sin(i * 45 * Math.PI / 180) * 180],
                      opacity: [1, 0],
                      scale: [1, 0]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeOut"
                    }}
                  />
                ))}
              </>
            )}
          </motion.div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`flex items-center gap-3 px-10 py-5 rounded-2xl font-semibold text-white shadow-xl hover:shadow-2xl transition-all transform hover:scale-105 ${
              isPlaying 
                ? "bg-gradient-to-r from-red-500 to-pink-500" 
                : "bg-gradient-to-r from-blue-500 to-cyan-500"
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-6 h-6" />
                Pause Session
              </>
            ) : (
              <>
                <Play className="w-6 h-6" />
                Start Breathing
              </>
            )}
          </button>

          <button
            onClick={() => {
              setSessionsCompleted(0);
              setTotalTime(0);
              setPhase("inhale");
              setCount(4);
              setIsPlaying(false);
            }}
            className="flex items-center gap-3 px-10 py-5 bg-white rounded-2xl font-semibold text-gray-700 shadow-xl hover:shadow-2xl transition-all transform hover:scale-105 border border-gray-200"
          >
            <RotateCcw className="w-6 h-6" />
            Reset
          </button>
        </div>

        {/* Instructions */}
        <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-2xl p-6 border border-blue-100">
          <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Target className="w-5 h-5 text-blue-600" />
            How It Works
          </h4>
          <div className="text-sm text-gray-600 text-left space-y-2">
            <p>• <strong>Inhale (4s):</strong> Breathe in slowly through your nose, filling your lungs completely</p>
            <p>• <strong>Hold (4s):</strong> Pause and hold your breath comfortably</p>
            <p>• <strong>Exhale (4s):</strong> Release slowly through your mouth, emptying your lungs fully</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

/* Color Matching Game */
function ColorMatchGame() {
  const [score, setScore] = useState(0);
  const [targetColor, setTargetColor] = useState("");
  const [options, setOptions] = useState<string[]>([]);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);

  const colors = [
    { name: "Serene Blue", value: "#4F8EF7" },
    { name: "Calm Teal", value: "#00C9A7" },
    { name: "Peaceful Purple", value: "#8B7FE6" },
    { name: "Gentle Pink", value: "#FF8DC7" },
    { name: "Soft Lavender", value: "#B8A4E8" },
    { name: "Tranquil Cyan", value: "#5ED4F3" },
    { name: "Warm Coral", value: "#FF9B9B" },
    { name: "Fresh Mint", value: "#7DFFCA" },
  ];

  useEffect(() => {
    generateNewRound();
  }, []);

  const generateNewRound = () => {
    const shuffled = [...colors].sort(() => Math.random() - 0.5);
    const target = shuffled[0];
    const opts = shuffled.slice(0, 4).sort(() => Math.random() - 0.5);
    
    setTargetColor(target.name);
    setOptions(opts.map(c => c.value));
    setFeedback(null);
  };

  const handleChoice = (chosenColor: string) => {
    const correctColor = colors.find(c => c.name === targetColor)?.value;
    
    if (chosenColor === correctColor) {
      setFeedback("correct");
      setScore((s) => s + 10);
      setStreak((s) => {
        const newStreak = s + 1;
        if (newStreak > bestStreak) setBestStreak(newStreak);
        return newStreak;
      });
      setTimeout(() => generateNewRound(), 800);
    } else {
      setFeedback("wrong");
      setStreak(0);
      setTimeout(() => setFeedback(null), 800);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-white/70 backdrop-blur-xl rounded-3xl p-8 md:p-12 shadow-2xl border border-white/50"
    >
      <div className="space-y-8">
        {/* Header with Stats */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-lg">
              <Palette className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Color Harmony
              </h2>
              <p className="text-gray-600">Match the calming colors</p>
            </div>
          </div>
          
          <div className="flex gap-3">
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl px-5 py-3 shadow-md border border-purple-100">
              <div className="text-xs text-gray-600 font-medium">Score</div>
              <div className="text-2xl font-bold text-purple-600 flex items-center gap-1">
                <Award className="w-5 h-5" />
                {score}
              </div>
            </div>
            <div className="bg-gradient-to-r from-orange-50 to-yellow-50 rounded-xl px-5 py-3 shadow-md border border-orange-100">
              <div className="text-xs text-gray-600 font-medium">Streak</div>
              <div className="text-2xl font-bold text-orange-600 flex items-center gap-1">
                <Zap className="w-5 h-5" />
                {streak}
              </div>
            </div>
            <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl px-5 py-3 shadow-md border border-blue-100">
              <div className="text-xs text-gray-600 font-medium">Best</div>
              <div className="text-2xl font-bold text-blue-600 flex items-center gap-1">
                <Trophy className="w-5 h-5" />
                {bestStreak}
              </div>
            </div>
          </div>
        </div>

        {/* Game Area */}
        <div className="bg-gradient-to-br from-purple-50/50 to-pink-50/50 rounded-2xl p-10 shadow-inner border border-purple-100/50">
          <div className="text-center mb-8">
            <p className="text-gray-600 text-lg mb-3">Find this color:</p>
            <motion.h3 
              key={targetColor}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-5xl font-bold text-gray-800 mb-2"
            >
              {targetColor}
            </motion.h3>
            <div className="inline-block px-4 py-2 bg-white/50 rounded-full text-sm text-gray-600">
              Tap the matching color below
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6 max-w-2xl mx-auto">
            {options.map((color, index) => (
              <motion.button
                key={index}
                initial={{ scale: 0, rotate: -10 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05, rotate: 2 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleChoice(color)}
                className="h-40 rounded-3xl shadow-xl hover:shadow-2xl transition-all relative overflow-hidden group"
                style={{ backgroundColor: color }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.button>
            ))}
          </div>
        </div>

        {/* Feedback */}
        <AnimatePresence>
          {feedback && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.8 }}
              className={`text-center p-6 rounded-2xl ${
                feedback === "correct" 
                  ? "bg-gradient-to-r from-green-400 to-emerald-500" 
                  : "bg-gradient-to-r from-red-400 to-pink-500"
              } text-white shadow-xl`}
            >
              <div className="text-4xl font-bold mb-2">
                {feedback === "correct" ? "✨ Perfect Match!" : "❌ Try Again"}
              </div>
              <div className="text-lg">
                {feedback === "correct" ? `+10 points • ${streak} streak` : "Keep practicing!"}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

/* Memory Game */
function MemoryGame() {
  const [cards, setCards] = useState<{ id: number; icon: any; flipped: boolean; matched: boolean }[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [matches, setMatches] = useState(0);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [gameStarted, setGameStarted] = useState(false);

  const icons = [Circle, Square, Triangle, Star, Heart, Sparkles];

  useEffect(() => {
    initializeGame();
  }, []);

  useEffect(() => {
    if (!gameStarted || matches === 6) return;

    const timer = setInterval(() => {
      setTimeElapsed((t) => t + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [gameStarted, matches]);

  const initializeGame = () => {
    const gameIcons = [...icons, ...icons]
      .sort(() => Math.random() - 0.5)
      .map((icon, index) => ({
        id: index,
        icon,
        flipped: false,
        matched: false,
      }));
    setCards(gameIcons);
    setFlippedIndices([]);
    setMoves(0);
    setMatches(0);
    setTimeElapsed(0);
    setGameStarted(false);
  };

  const handleCardClick = (index: number) => {
    if (!gameStarted) setGameStarted(true);
    if (flippedIndices.length === 2 || cards[index].flipped || cards[index].matched) return;

    const newCards = [...cards];
    newCards[index].flipped = true;
    setCards(newCards);

    const newFlipped = [...flippedIndices, index];
    setFlippedIndices(newFlipped);

    if (newFlipped.length === 2) {
      setMoves((m) => m + 1);
      const [first, second] = newFlipped;

      if (cards[first].icon === cards[second].icon) {
        setTimeout(() => {
          const matchedCards = [...cards];
          matchedCards[first].matched = true;
          matchedCards[second].matched = true;
          setCards(matchedCards);
          setFlippedIndices([]);
          setMatches((m) => m + 1);
        }, 500);
      } else {
        setTimeout(() => {
          const resetCards = [...cards];
          resetCards[first].flipped = false;
          resetCards[second].flipped = false;
          setCards(resetCards);
          setFlippedIndices([]);
        }, 1000);
      }
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-white/70 backdrop-blur-xl rounded-3xl p-8 md:p-12 shadow-2xl border border-white/50"
    >
      <div className="space-y-8">
        {/* Header with Stats */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-teal-500 to-emerald-500 flex items-center justify-center shadow-lg">
              <Brain className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-3xl font-bold bg-gradient-to-r from-teal-600 to-emerald-600 bg-clip-text text-transparent">
                Mindful Memory
              </h2>
              <p className="text-gray-600">Find all matching pairs</p>
            </div>
          </div>
          
          <div className="flex gap-3">
            <div className="bg-gradient-to-r from-teal-50 to-emerald-50 rounded-xl px-5 py-3 shadow-md border border-teal-100">
              <div className="text-xs text-gray-600 font-medium">Moves</div>
              <div className="text-2xl font-bold text-teal-600">{moves}</div>
            </div>
            <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl px-5 py-3 shadow-md border border-blue-100">
              <div className="text-xs text-gray-600 font-medium">Time</div>
              <div className="text-2xl font-bold text-blue-600">{Math.floor(timeElapsed / 60)}:{(timeElapsed % 60).toString().padStart(2, '0')}</div>
            </div>
            <div className="bg-gradient-to-r from-green-50 to-lime-50 rounded-xl px-5 py-3 shadow-md border border-green-100">
              <div className="text-xs text-gray-600 font-medium">Matches</div>
              <div className="text-2xl font-bold text-green-600">{matches}/6</div>
            </div>
          </div>
        </div>

        {/* Game Grid */}
        <div className="grid grid-cols-4 gap-4">
          {cards.map((card, index) => {
            const Icon = card.icon;
            return (
              <motion.button
                key={card.id}
                initial={{ scale: 0, rotate: -10 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ scale: card.flipped || card.matched ? 1 : 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleCardClick(index)}
                className={`h-28 rounded-2xl shadow-lg transition-all relative overflow-hidden ${
                  card.flipped || card.matched
                    ? "bg-gradient-to-br from-teal-400 to-emerald-500"
                    : "bg-white hover:bg-gray-50"
                }`}
              >
                {(card.flipped || card.matched) ? (
                  <motion.div
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ type: "spring", stiffness: 200 }}
                  >
                    <Icon className="w-12 h-12 text-white mx-auto" />
                  </motion.div>
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <div className="w-8 h-8 bg-gradient-to-br from-gray-200 to-gray-300 rounded-lg" />
                  </div>
                )}

                {card.matched && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute top-2 right-2 w-6 h-6 bg-white rounded-full flex items-center justify-center"
                  >
                    <Check className="w-4 h-4 text-green-600" />
                  </motion.div>
                )}
              </motion.button>
            );
          })}
        </div>

        {/* Victory Screen */}
        {matches === 6 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gradient-to-r from-teal-500 to-emerald-500 rounded-2xl p-8 text-white text-center shadow-2xl"
          >
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 2 }}
            >
              <Trophy className="w-20 h-20 mx-auto mb-4" />
            </motion.div>
            <h3 className="text-3xl font-bold mb-3">Excellent Work!</h3>
            <p className="text-xl mb-2">You completed the game in {moves} moves</p>
            <p className="text-lg mb-6">Time: {Math.floor(timeElapsed / 60)}:{(timeElapsed % 60).toString().padStart(2, '0')}</p>
            <button
              onClick={initializeGame}
              className="px-8 py-4 bg-white text-teal-600 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all transform hover:scale-105"
            >
              Play Again
            </button>
          </motion.div>
        )}

        <button
          onClick={initializeGame}
          className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-white rounded-xl font-semibold text-gray-700 shadow-lg hover:shadow-xl transition-all border border-gray-200"
        >
          <RotateCcw className="w-5 h-5" />
          New Game
        </button>
      </div>
    </motion.div>
  );
}

/* Zen Drawing Game */
function ZenDrawGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [color, setColor] = useState("#4F8EF7");
  const [brushSize, setBrushSize] = useState(5);

  const colors = [
    { name: "Serene Blue", value: "#4F8EF7" },
    { name: "Calm Teal", value: "#00C9A7" },
    { name: "Peaceful Purple", value: "#8B7FE6" },
    { name: "Gentle Pink", value: "#FF8DC7" },
    { name: "Warm Coral", value: "#FFA94D" },
    { name: "Tranquil Cyan", value: "#5ED4F3" }
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }, []);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    draw(e);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (ctx) ctx.beginPath();
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;

    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!ctx || !canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.lineWidth = brushSize;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = color;

    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!ctx || !canvas) return;

    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-white/70 backdrop-blur-xl rounded-3xl p-8 md:p-12 shadow-2xl border border-white/50"
    >
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center shadow-lg">
              <Sparkles className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
                Zen Drawing
              </h2>
              <p className="text-gray-600">Express yourself freely</p>
            </div>
          </div>
          
          <button
            onClick={clearCanvas}
            className="flex items-center gap-2 px-6 py-3 bg-white rounded-xl font-semibold text-gray-700 shadow-lg hover:shadow-xl transition-all border border-gray-200"
          >
            <RotateCcw className="w-5 h-5" />
            Clear Canvas
          </button>
        </div>

        {/* Canvas */}
        <div className="bg-gradient-to-br from-indigo-50/50 to-violet-50/50 rounded-2xl p-4 shadow-inner border border-indigo-100/50">
          <canvas
            ref={canvasRef}
            onMouseDown={startDrawing}
            onMouseUp={stopDrawing}
            onMouseMove={draw}
            onMouseLeave={stopDrawing}
            className="w-full h-[500px] rounded-xl cursor-crosshair bg-white shadow-lg"
          />
        </div>

        {/* Tools */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Color Palette */}
          <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-100">
            <h4 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <Palette className="w-5 h-5 text-purple-600" />
              Color Palette
            </h4>
            <div className="flex flex-wrap gap-3">
              {colors.map((c) => (
                <motion.button
                  key={c.value}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setColor(c.value)}
                  className={`w-14 h-14 rounded-xl shadow-lg hover:shadow-xl transition-all relative ${
                    color === c.value ? "ring-4 ring-offset-2 ring-indigo-400" : ""
                  }`}
                  style={{ backgroundColor: c.value }}
                  title={c.name}
                >
                  {color === c.value && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute inset-0 flex items-center justify-center"
                    >
                      <Check className="w-6 h-6 text-white drop-shadow-lg" />
                    </motion.div>
                  )}
                </motion.button>
              ))}
            </div>
          </div>

          {/* Brush Size */}
          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-6 border border-blue-100">
            <h4 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <Circle className="w-5 h-5 text-blue-600" />
              Brush Size
            </h4>
            <div className="space-y-4">
              <input
                type="range"
                min="1"
                max="20"
                value={brushSize}
                onChange={(e) => setBrushSize(Number(e.target.value))}
                className="w-full"
              />
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Size: {brushSize}px</span>
                <div 
                  className="rounded-full shadow-md"
                  style={{ 
                    width: `${brushSize * 2}px`, 
                    height: `${brushSize * 2}px`,
                    backgroundColor: color 
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-gradient-to-r from-indigo-50 to-violet-50 rounded-2xl p-6 border border-indigo-100">
          <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-600" />
            Zen Drawing Benefits
          </h4>
          <div className="grid md:grid-cols-3 gap-4 text-sm text-gray-600">
            <div className="flex items-start gap-2">
              <Check className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
              <span>Reduces stress and anxiety through creative expression</span>
            </div>
            <div className="flex items-start gap-2">
              <Check className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
              <span>Promotes mindfulness and present-moment awareness</span>
            </div>
            <div className="flex items-start gap-2">
              <Check className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
              <span>Enhances emotional well-being and self-expression</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
