import { useState, useEffect } from "react";
import { AlertTriangle, Coffee, Wind, Droplets, Heart, CheckCircle, Clock, XCircle } from "lucide-react";

interface Alert {
  id: string;
  type: "high" | "medium" | "low";
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  suggestions: string[];
}

export function Alerts() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [filter, setFilter] = useState<"all" | "high" | "medium" | "low">("all");

  useEffect(() => {
    generateMockAlerts();
  }, []);

  const generateMockAlerts = () => {
    const mockAlerts: Alert[] = [
      {
        id: "1",
        type: "high",
        title: "High Stress Level Detected",
        message: "Your stress level has reached 85%. Immediate attention recommended.",
        timestamp: new Date().toLocaleString(),
        read: false,
        suggestions: [
          "Take a 10-minute break from your current task",
          "Practice deep breathing exercises (4-7-8 technique)",
          "Drink a glass of water",
          "Step outside for fresh air",
        ],
      },
      {
        id: "2",
        type: "medium",
        title: "Elevated Heart Rate",
        message: "Your heart rate has been consistently above 95 bpm for the last 30 minutes.",
        timestamp: new Date(Date.now() - 1800000).toLocaleString(),
        read: false,
        suggestions: [
          "Consider taking a short walk",
          "Practice progressive muscle relaxation",
          "Ensure you're well hydrated",
        ],
      },
      {
        id: "3",
        type: "low",
        title: "Stress Levels Normal",
        message: "Your stress indicators are within healthy ranges. Keep up the good work!",
        timestamp: new Date(Date.now() - 3600000).toLocaleString(),
        read: true,
        suggestions: [
          "Maintain your current routine",
          "Stay hydrated throughout the day",
          "Continue regular breaks",
        ],
      },
      {
        id: "4",
        type: "high",
        title: "Prolonged Stress Detection",
        message: "Elevated stress levels detected for over 2 hours. Please take action.",
        timestamp: new Date(Date.now() - 7200000).toLocaleString(),
        read: true,
        suggestions: [
          "Take an extended break (20-30 minutes)",
          "Practice meditation or mindfulness",
          "Consider reaching out to a wellness professional",
          "Engage in light physical activity",
        ],
      },
      {
        id: "5",
        type: "medium",
        title: "Hydration Reminder",
        message: "Temperature readings suggest you may need hydration.",
        timestamp: new Date(Date.now() - 10800000).toLocaleString(),
        read: true,
        suggestions: [
          "Drink a full glass of water",
          "Avoid caffeinated beverages temporarily",
          "Monitor your fluid intake",
        ],
      },
    ];

    setAlerts(mockAlerts);
  };

  const markAsRead = (id: string) => {
    setAlerts((prev) =>
      prev.map((alert) => (alert.id === id ? { ...alert, read: true } : alert))
    );
  };

  const markAllAsRead = () => {
    setAlerts((prev) => prev.map((alert) => ({ ...alert, read: true })));
  };

  const deleteAlert = (id: string) => {
    setAlerts((prev) => prev.filter((alert) => alert.id !== id));
  };

  const filteredAlerts = alerts.filter((alert) =>
    filter === "all" ? true : alert.type === filter
  );

  const getAlertStyle = (type: string) => {
    switch (type) {
      case "high":
        return {
          bg: "bg-red-50 border-red-200",
          icon: "text-red-600",
          badge: "bg-red-500",
          button: "hover:bg-red-100",
        };
      case "medium":
        return {
          bg: "bg-yellow-50 border-yellow-200",
          icon: "text-yellow-600",
          badge: "bg-yellow-500",
          button: "hover:bg-yellow-100",
        };
      case "low":
        return {
          bg: "bg-green-50 border-green-200",
          icon: "text-green-600",
          badge: "bg-green-500",
          button: "hover:bg-green-100",
        };
      default:
        return {
          bg: "bg-gray-50 border-gray-200",
          icon: "text-gray-600",
          badge: "bg-gray-500",
          button: "hover:bg-gray-100",
        };
    }
  };

  const unreadCount = alerts.filter((a) => !a.read).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl text-gray-800">Alerts & Notifications</h1>
            {unreadCount > 0 && (
              <span className="px-3 py-1 bg-red-500 text-white text-sm rounded-full">
                {unreadCount} new
              </span>
            )}
          </div>
          <p className="text-gray-600">Health alerts and wellness recommendations</p>
        </div>
        {unreadCount > 0 && (
          <button
            onClick={markAllAsRead}
            className="flex items-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors"
          >
            <CheckCircle className="w-4 h-4" />
            Mark All as Read
          </button>
        )}
      </div>

      {/* Filter Buttons */}
      <div className="flex gap-2 flex-wrap">
        {["all", "high", "medium", "low"].map((type) => (
          <button
            key={type}
            onClick={() => setFilter(type as any)}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              filter === type
                ? "bg-gradient-to-r from-teal-600 to-blue-600 text-white shadow-md"
                : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-300"
            }`}
          >
            {type.charAt(0).toUpperCase() + type.slice(1)}
            {type !== "all" && (
              <span className="ml-2 text-xs opacity-75">
                ({alerts.filter((a) => a.type === type).length})
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Quick Actions - Wellness Tips */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-xl p-4 shadow-lg">
          <Coffee className="w-8 h-8 mb-2 opacity-90" />
          <h3 className="font-semibold mb-1">Take a Break</h3>
          <p className="text-sm opacity-90">Step away for 5-10 minutes</p>
        </div>
        <div className="bg-gradient-to-br from-teal-500 to-teal-600 text-white rounded-xl p-4 shadow-lg">
          <Wind className="w-8 h-8 mb-2 opacity-90" />
          <h3 className="font-semibold mb-1">Breathing Exercise</h3>
          <p className="text-sm opacity-90">4-7-8 breathing technique</p>
        </div>
        <div className="bg-gradient-to-br from-cyan-500 to-cyan-600 text-white rounded-xl p-4 shadow-lg">
          <Droplets className="w-8 h-8 mb-2 opacity-90" />
          <h3 className="font-semibold mb-1">Stay Hydrated</h3>
          <p className="text-sm opacity-90">Drink a glass of water</p>
        </div>
        <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white rounded-xl p-4 shadow-lg">
          <Heart className="w-8 h-8 mb-2 opacity-90" />
          <h3 className="font-semibold mb-1">Mindfulness</h3>
          <p className="text-sm opacity-90">2-minute meditation</p>
        </div>
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {filteredAlerts.length === 0 ? (
          <div className="bg-white rounded-xl shadow-md p-12 text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-xl text-gray-800 mb-2">No alerts to display</h3>
            <p className="text-gray-600">
              {filter === "all"
                ? "You're all caught up! No new alerts."
                : `No ${filter} priority alerts at the moment.`}
            </p>
          </div>
        ) : (
          filteredAlerts.map((alert) => {
            const style = getAlertStyle(alert.type);
            return (
              <div
                key={alert.id}
                className={`bg-white rounded-xl shadow-md border-l-4 overflow-hidden transition-all ${
                  !alert.read ? "border-l-4" : "opacity-75"
                } ${style.bg}`}
              >
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start gap-4 flex-1">
                      <div className={`p-3 rounded-full ${style.bg}`}>
                        <AlertTriangle className={`w-6 h-6 ${style.icon}`} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-lg text-gray-800">{alert.title}</h3>
                          {!alert.read && (
                            <span className={`w-2 h-2 rounded-full ${style.badge}`} />
                          )}
                        </div>
                        <p className="text-gray-700 mb-2">{alert.message}</p>
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <Clock className="w-4 h-4" />
                          <span>{alert.timestamp}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {!alert.read && (
                        <button
                          onClick={() => markAsRead(alert.id)}
                          className={`p-2 rounded-lg ${style.button} transition-colors`}
                          title="Mark as read"
                        >
                          <CheckCircle className="w-5 h-5 text-gray-600" />
                        </button>
                      )}
                      <button
                        onClick={() => deleteAlert(alert.id)}
                        className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                        title="Dismiss"
                      >
                        <XCircle className="w-5 h-5 text-gray-600" />
                      </button>
                    </div>
                  </div>

                  {/* Suggestions */}
                  {alert.suggestions.length > 0 && (
                    <div className="bg-white bg-opacity-60 rounded-lg p-4 mt-4">
                      <h4 className="text-sm text-gray-700 mb-3">
                        💡 Recommended Actions:
                      </h4>
                      <ul className="space-y-2">
                        {alert.suggestions.map((suggestion, idx) => (
                          <li
                            key={idx}
                            className="flex items-start gap-2 text-sm text-gray-700"
                          >
                            <span className="text-teal-600 mt-0.5">•</span>
                            <span>{suggestion}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Emergency Contact Card */}
      <div className="bg-gradient-to-r from-red-500 to-pink-600 text-white rounded-xl shadow-lg p-6">
        <div className="flex items-start gap-4">
          <AlertTriangle className="w-8 h-8 flex-shrink-0" />
          <div>
            <h3 className="text-xl mb-2">Emergency Support</h3>
            <p className="mb-4 opacity-90">
              If you're experiencing severe stress or a medical emergency, please seek
              immediate professional help.
            </p>
            <div className="flex gap-3 flex-wrap">
              <button className="px-4 py-2 bg-white text-red-600 rounded-lg hover:bg-gray-100 transition-colors font-medium">
                Contact Wellness Team
              </button>
              <button className="px-4 py-2 bg-red-700 text-white rounded-lg hover:bg-red-800 transition-colors font-medium">
                Emergency: 911
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
