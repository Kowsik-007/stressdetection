import { useState, useEffect } from "react";
import { Download, Calendar, TrendingUp } from "lucide-react";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import axios from "axios";

interface HistoryData {
  date: string;
  avgHeartRate: number;
  stressLevel: string;
  riskPercentage: number;
}

export function History() {
  const [selectedDate, setSelectedDate] = useState("");
  const [historyData, setHistoryData] = useState<HistoryData[]>([]);
  const [weeklyData, setWeeklyData] = useState<any[]>([]);

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    try {
      // Mock API call
      // const user = JSON.parse(localStorage.getItem("user") || "{}");
      // const response = await axios.get(`http://your-api-url/history/${user.userId}`);
      
      // Generate mock historical data
      const mockData: HistoryData[] = [];
      const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
      
      for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const avgHR = Math.floor(70 + Math.random() * 20);
        const risk = Math.floor(Math.random() * 100);
        let level = "Low";
        if (risk > 70) level = "High";
        else if (risk > 40) level = "Medium";

        mockData.push({
          date: date.toLocaleDateString(),
          avgHeartRate: avgHR,
          stressLevel: level,
          riskPercentage: risk,
        });
      }

      setHistoryData(mockData);

      // Prepare weekly chart data
      const chartData = mockData.map((item, idx) => ({
        day: days[idx] || "Day " + (idx + 1),
        heartRate: item.avgHeartRate,
        stress: item.riskPercentage,
      }));

      setWeeklyData(chartData);
    } catch (error) {
      console.error("Error fetching history:", error);
    }
  };

  const handleDownloadReport = () => {
    // Generate CSV report
    let csv = "Date,Avg Heart Rate,Stress Level,Risk Percentage\n";
    historyData.forEach((item) => {
      csv += `${item.date},${item.avgHeartRate},${item.stressLevel},${item.riskPercentage}%\n`;
    });

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `stress_report_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const getStressColor = (level: string) => {
    switch (level) {
      case "Low":
        return "text-green-600 bg-green-100";
      case "Medium":
        return "text-yellow-600 bg-yellow-100";
      case "High":
        return "text-red-600 bg-red-100";
      default:
        return "text-gray-600 bg-gray-100";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl text-gray-800">History</h1>
          <p className="text-gray-600">View your stress patterns and trends over time</p>
        </div>
        <div className="flex gap-3">
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none"
            />
          </div>
          <button
            onClick={handleDownloadReport}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-600 to-blue-600 text-white rounded-lg hover:from-teal-700 hover:to-blue-700 shadow-md hover:shadow-lg transition-all"
          >
            <Download className="w-4 h-4" />
            Download Report
          </button>
        </div>
      </div>

      {/* Weekly Stress Trend Chart */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-2 mb-6">
          <TrendingUp className="w-5 h-5 text-teal-600" />
          <h2 className="text-xl text-gray-800">Weekly Stress Trend</h2>
        </div>
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={weeklyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="day" stroke="#999" />
            <YAxis stroke="#999" />
            <Tooltip
              contentStyle={{
                backgroundColor: "#fff",
                border: "1px solid #e5e7eb",
                borderRadius: "8px",
              }}
            />
            <Legend />
            <Bar dataKey="stress" fill="#14b8a6" name="Stress Level %" radius={[8, 8, 0, 0]} />
            <Bar dataKey="heartRate" fill="#3b82f6" name="Avg Heart Rate" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Combined Line Chart */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl text-gray-800 mb-6">Heart Rate & Stress Correlation</h2>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={weeklyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="day" stroke="#999" />
            <YAxis stroke="#999" />
            <Tooltip
              contentStyle={{
                backgroundColor: "#fff",
                border: "1px solid #e5e7eb",
                borderRadius: "8px",
              }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="heartRate"
              stroke="#3b82f6"
              strokeWidth={3}
              dot={{ fill: "#3b82f6", r: 5 }}
              name="Heart Rate"
            />
            <Line
              type="monotone"
              dataKey="stress"
              stroke="#ef4444"
              strokeWidth={3}
              dot={{ fill: "#ef4444", r: 5 }}
              name="Stress %"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* History Table */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl text-gray-800">Detailed Records</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-left text-sm text-gray-700">Date</th>
                <th className="px-6 py-4 text-left text-sm text-gray-700">Avg Heart Rate</th>
                <th className="px-6 py-4 text-left text-sm text-gray-700">Stress Level</th>
                <th className="px-6 py-4 text-left text-sm text-gray-700">Risk Percentage</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {historyData.map((item, index) => (
                <tr key={index} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 text-gray-800">{item.date}</td>
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center gap-2 text-gray-800">
                      {item.avgHeartRate} bpm
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStressColor(item.stressLevel)}`}>
                      {item.stressLevel}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[200px]">
                        <div
                          className={`h-2 rounded-full ${
                            item.riskPercentage > 70
                              ? "bg-red-500"
                              : item.riskPercentage > 40
                              ? "bg-yellow-500"
                              : "bg-green-500"
                          }`}
                          style={{ width: `${item.riskPercentage}%` }}
                        />
                      </div>
                      <span className="text-gray-700 text-sm min-w-[50px]">
                        {item.riskPercentage}%
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-green-500 to-teal-600 text-white rounded-xl p-6 shadow-lg">
          <p className="text-sm opacity-90 mb-1">Low Stress Days</p>
          <p className="text-3xl mb-1">
            {historyData.filter((d) => d.stressLevel === "Low").length}
          </p>
          <p className="text-sm opacity-75">This week</p>
        </div>
        <div className="bg-gradient-to-br from-yellow-500 to-orange-600 text-white rounded-xl p-6 shadow-lg">
          <p className="text-sm opacity-90 mb-1">Medium Stress Days</p>
          <p className="text-3xl mb-1">
            {historyData.filter((d) => d.stressLevel === "Medium").length}
          </p>
          <p className="text-sm opacity-75">This week</p>
        </div>
        <div className="bg-gradient-to-br from-red-500 to-pink-600 text-white rounded-xl p-6 shadow-lg">
          <p className="text-sm opacity-90 mb-1">High Stress Days</p>
          <p className="text-3xl mb-1">
            {historyData.filter((d) => d.stressLevel === "High").length}
          </p>
          <p className="text-sm opacity-75">This week</p>
        </div>
      </div>
    </div>
  );
}
