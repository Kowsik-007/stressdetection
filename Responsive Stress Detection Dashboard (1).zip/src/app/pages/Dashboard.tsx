import { useState, useEffect } from "react";
import { Moon, Sun, Coffee, Smartphone, Smile, Brain, TrendingUp, Activity } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts";
import { StressMeter } from "../components/StressMeter";
import { motion } from "motion/react";
import axios from "axios";

interface BehavioralData {
  sleepHours: number;
  workHours: number;
  screenTime: number;
  mood: string;
}

interface StressData {
  score: number;
  timestamp: string;
}

export function Dashboard() {
  const [stressScore, setStressScore] = useState(45);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<BehavioralData>({
    sleepHours: 7,
    workHours: 8,
    screenTime: 5,
    mood: "Neutral",
  });

  const [stressHistory, setStressHistory] = useState<StressData[]>([
    { score: 35, timestamp: "Mon" },
    { score: 42, timestamp: "Tue" },
    { score: 38, timestamp: "Wed" },
    { score: 55, timestamp: "Thu" },
    { score: 48, timestamp: "Fri" },
    { score: 40, timestamp: "Sat" },
    { score: 45, timestamp: "Sun" },
  ]);

  const [insights, setInsights] = useState({
    sleepQuality: "Good",
    workBalance: "Moderate",
    screenWarning: false,
    moodTrend: "Stable",
  });

  // Calculate stress based on behavioral inputs
  const calculateStress = async () => {
    setLoading(true);

    try {
      // API call (replace with your backend endpoint)
      // const response = await axios.post('/api/calculate-stress', formData);
      // setStressScore(response.data.stressScore);

      // Mock calculation logic
      let baseScore = 0;

      // Sleep factor (0-30 points)
      if (formData.sleepHours < 6) baseScore += 25;
      else if (formData.sleepHours < 7) baseScore += 15;
      else if (formData.sleepHours > 9) baseScore += 10;

      // Work hours factor (0-30 points)
      if (formData.workHours > 10) baseScore += 30;
      else if (formData.workHours > 8) baseScore += 20;
      else if (formData.workHours < 4) baseScore += 15;

      // Screen time factor (0-20 points)
      if (formData.screenTime > 8) baseScore += 20;
      else if (formData.screenTime > 6) baseScore += 12;

      // Mood factor (0-20 points)
      const moodScores: Record<string, number> = {
        "Happy": 0,
        "Neutral": 10,
        "Anxious": 20,
        "Tired": 15,
      };
      baseScore += moodScores[formData.mood] || 0;

      const finalScore = Math.min(100, Math.max(0, baseScore));
      setStressScore(finalScore);

      // Update history
      const newEntry = {
        score: finalScore,
        timestamp: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
      };
      setStressHistory((prev) => [...prev.slice(-6), newEntry]);

      // Update insights
      updateInsights(formData, finalScore);
    } catch (error) {
      console.error("Error calculating stress:", error);
    } finally {
      setLoading(false);
    }
  };

  const updateInsights = (data: BehavioralData, score: number) => {
    setInsights({
      sleepQuality: data.sleepHours >= 7 && data.sleepHours <= 9 ? "Good" : "Needs Improvement",
      workBalance: data.workHours <= 8 ? "Good" : "Overworking",
      screenWarning: data.screenTime > 6,
      moodTrend: score > 60 ? "Declining" : score < 40 ? "Improving" : "Stable",
    });
  };

  const MetricCard = ({ 
    icon: Icon, 
    title, 
    value, 
    unit, 
    color, 
    gradient 
  }: { 
    icon: any; 
    title: string; 
    value: number; 
    unit: string; 
    color: string; 
    gradient: string;
  }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-gray-100"
    >
      <div className="flex items-start justify-between mb-4">
        <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center shadow-lg`}>
          <Icon className="w-7 h-7 text-white" />
        </div>
      </div>
      <h3 className="text-gray-500 text-sm mb-2">{title}</h3>
      <div className="flex items-baseline gap-2">
        <span className={`text-4xl font-bold bg-gradient-to-r ${gradient} bg-clip-text text-transparent`}>
          {value}
        </span>
        <span className="text-gray-400 text-lg">{unit}</span>
      </div>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5F9FF] via-white to-[#F0F4FF]">
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-1">
              AI Stress Detection Dashboard
            </h1>
            <p className="text-gray-500">Behavioral pattern analysis powered by machine learning</p>
          </div>
          <div className="px-4 py-2 bg-gradient-to-r from-[#4F8EF7] to-[#00C9A7] text-white rounded-full text-sm font-semibold shadow-lg">
            🤖 AI Powered
          </div>
        </motion.div>

        {/* Main Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column - Stress Meter */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-1"
          >
            <div className="bg-white rounded-2xl p-8 shadow-xl border border-gray-100">
              <h2 className="text-xl font-semibold text-gray-800 mb-6 text-center">
                Current Stress Level
              </h2>
              <StressMeter score={stressScore} />
              
              {/* Quick Stats */}
              <div className="mt-8 space-y-3">
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-teal-50 rounded-xl">
                  <span className="text-sm text-gray-600">Today's Average</span>
                  <span className="font-semibold text-[#4F8EF7]">{stressScore}%</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl">
                  <span className="text-sm text-gray-600">7-Day Average</span>
                  <span className="font-semibold text-[#8B7FE6]">42%</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right Column - Metrics & Input */}
          <div className="lg:col-span-2 space-y-6">
            {/* Behavioral Metrics */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <MetricCard
                icon={Moon}
                title="Sleep Hours"
                value={formData.sleepHours}
                unit="hrs"
                color="#4F8EF7"
                gradient="from-blue-400 to-blue-600"
              />
              <MetricCard
                icon={Coffee}
                title="Work Hours"
                value={formData.workHours}
                unit="hrs"
                color="#8B7FE6"
                gradient="from-purple-400 to-purple-600"
              />
              <MetricCard
                icon={Smartphone}
                title="Screen Time"
                value={formData.screenTime}
                unit="hrs"
                color="#00C9A7"
                gradient="from-teal-400 to-emerald-600"
              />
              <MetricCard
                icon={Smile}
                title="Mood"
                value={formData.mood === "Happy" ? "😊" : formData.mood === "Neutral" ? "😐" : formData.mood === "Anxious" ? "😰" : "😴"}
                unit=""
                color="#FFA94D"
                gradient="from-orange-400 to-yellow-500"
              />
            </div>

            {/* Input Form */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-2xl p-6 shadow-xl border border-gray-100"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#4F8EF7] to-[#00C9A7] flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-xl font-semibold text-gray-800">
                  Update Your Behavioral Data
                </h2>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                {/* Mood Dropdown */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Current Mood
                  </label>
                  <select
                    value={formData.mood}
                    onChange={(e) => setFormData({ ...formData, mood: e.target.value })}
                    className="w-full px-4 py-3 bg-gradient-to-r from-gray-50 to-blue-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#4F8EF7] transition-all"
                  >
                    <option value="Happy">😊 Happy</option>
                    <option value="Neutral">😐 Neutral</option>
                    <option value="Anxious">😰 Anxious</option>
                    <option value="Tired">😴 Tired</option>
                  </select>
                </div>

                {/* Sleep Hours */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Sleep Hours (last night)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="24"
                    step="0.5"
                    value={formData.sleepHours}
                    onChange={(e) => setFormData({ ...formData, sleepHours: parseFloat(e.target.value) })}
                    className="w-full px-4 py-3 bg-gradient-to-r from-gray-50 to-purple-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#8B7FE6] transition-all"
                  />
                </div>

                {/* Work Hours */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Work Hours (today)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="24"
                    step="0.5"
                    value={formData.workHours}
                    onChange={(e) => setFormData({ ...formData, workHours: parseFloat(e.target.value) })}
                    className="w-full px-4 py-3 bg-gradient-to-r from-gray-50 to-teal-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#00C9A7] transition-all"
                  />
                </div>

                {/* Screen Time */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Screen Time (today)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="24"
                    step="0.5"
                    value={formData.screenTime}
                    onChange={(e) => setFormData({ ...formData, screenTime: parseFloat(e.target.value) })}
                    className="w-full px-4 py-3 bg-gradient-to-r from-gray-50 to-orange-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FFA94D] transition-all"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <button
                onClick={calculateStress}
                disabled={loading}
                className="w-full mt-6 px-6 py-4 bg-gradient-to-r from-[#4F8EF7] to-[#00C9A7] text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Analyzing...
                  </span>
                ) : (
                  <span className="flex items-center justify-center gap-2">
                    <Brain className="w-5 h-5" />
                    Calculate Stress Level
                  </span>
                )}
              </button>
            </motion.div>

            {/* AI Insights */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-gradient-to-br from-[#4F8EF7] to-[#8B7FE6] rounded-2xl p-6 shadow-xl text-white"
            >
              <div className="flex items-center gap-3 mb-4">
                <Activity className="w-6 h-6" />
                <h3 className="text-xl font-semibold">AI-Powered Insights</h3>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-white/10 backdrop-blur rounded-xl p-4">
                  <div className="text-sm text-white/80 mb-1">Sleep Quality</div>
                  <div className="text-lg font-semibold">{insights.sleepQuality}</div>
                </div>
                <div className="bg-white/10 backdrop-blur rounded-xl p-4">
                  <div className="text-sm text-white/80 mb-1">Work-Life Balance</div>
                  <div className="text-lg font-semibold">{insights.workBalance}</div>
                </div>
                <div className="bg-white/10 backdrop-blur rounded-xl p-4">
                  <div className="text-sm text-white/80 mb-1">Screen Time Status</div>
                  <div className="text-lg font-semibold">
                    {insights.screenWarning ? "⚠️ High" : "✅ Normal"}
                  </div>
                </div>
                <div className="bg-white/10 backdrop-blur rounded-xl p-4">
                  <div className="text-sm text-white/80 mb-1">Mood Trend</div>
                  <div className="text-lg font-semibold">{insights.moodTrend}</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Stress Trend Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-2xl p-6 shadow-xl border border-gray-100"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-6 h-6 text-[#4F8EF7]" />
              <h2 className="text-xl font-semibold text-gray-800">Stress Trend Analysis</h2>
            </div>
            <div className="px-4 py-2 bg-gradient-to-r from-purple-50 to-blue-50 text-[#4F8EF7] rounded-full text-sm font-semibold">
              Last 7 Days
            </div>
          </div>

          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={stressHistory}>
              <defs>
                <linearGradient id="stressGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4F8EF7" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#4F8EF7" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E9F2" />
              <XAxis dataKey="timestamp" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" domain={[0, 100]} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "white",
                  border: "none",
                  borderRadius: "12px",
                  boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                }}
              />
              <Area
                type="monotone"
                dataKey="score"
                stroke="#4F8EF7"
                strokeWidth={3}
                fill="url(#stressGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Recommendations */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="grid md:grid-cols-3 gap-4"
        >
          <div className="bg-gradient-to-br from-emerald-400 to-teal-500 rounded-2xl p-6 text-white shadow-xl">
            <div className="text-3xl mb-2">🧘</div>
            <h3 className="font-semibold mb-2">Meditation</h3>
            <p className="text-sm text-white/90">Try 10 minutes of mindfulness daily</p>
          </div>
          <div className="bg-gradient-to-br from-blue-400 to-purple-500 rounded-2xl p-6 text-white shadow-xl">
            <div className="text-3xl mb-2">💧</div>
            <h3 className="font-semibold mb-2">Hydration</h3>
            <p className="text-sm text-white/90">Drink 8 glasses of water per day</p>
          </div>
          <div className="bg-gradient-to-br from-orange-400 to-pink-500 rounded-2xl p-6 text-white shadow-xl">
            <div className="text-3xl mb-2">🚶</div>
            <h3 className="font-semibold mb-2">Movement</h3>
            <p className="text-sm text-white/90">Take breaks every hour to walk</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
