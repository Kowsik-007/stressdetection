export function LoadingSpinner({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const sizeClasses = {
    sm: "w-4 h-4 border-2",
    md: "w-8 h-8 border-3",
    lg: "w-12 h-12 border-4",
  };

  return (
    <div className="flex items-center justify-center min-h-[200px]">
      <div className="flex flex-col items-center gap-3">
        <div
          className={`${sizeClasses[size]} border-teal-600 border-t-transparent rounded-full animate-spin`}
        />
        <p className="text-gray-600 text-sm">Loading...</p>
      </div>
    </div>
  );
}
