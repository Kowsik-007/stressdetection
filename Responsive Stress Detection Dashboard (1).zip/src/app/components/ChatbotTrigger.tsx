// This component can be used to trigger chatbot alerts from other components
// Export this event emitter for cross-component communication

type ChatbotEventCallback = (data: any) => void;

class ChatbotEventEmitter {
  private listeners: ChatbotEventCallback[] = [];

  subscribe(callback: ChatbotEventCallback) {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter((cb) => cb !== callback);
    };
  }

  emit(data: any) {
    this.listeners.forEach((callback) => callback(data));
  }
}

export const chatbotEvents = new ChatbotEventEmitter();

// Helper function to send stress alert to chatbot
export const sendStressAlertToChat = (stressLevel: number, heartRate?: number) => {
  const severity = stressLevel > 80 ? "high" : stressLevel > 60 ? "medium" : "low";
  
  chatbotEvents.emit({
    type: "stress_alert",
    stressLevel,
    heartRate,
    severity,
  });
};
