import { motion } from "motion/react";

interface StressMeterProps {
  score: number; // 0-100
  size?: number;
}

export function StressMeter({ score, size = 280 }: StressMeterProps) {
  const getStressLevel = (score: number) => {
    if (score <= 40) return { level: "Low", color: "#00C9A7", gradient: "from-emerald-400 to-teal-500" };
    if (score <= 70) return { level: "Medium", color: "#FFA94D", gradient: "from-yellow-400 to-orange-500" };
    return { level: "High", color: "#FF5C5C", gradient: "from-red-400 to-pink-500" };
  };

  const { level, color, gradient } = getStressLevel(score);
  const circumference = 2 * Math.PI * 120;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="relative flex items-center justify-center">
      {/* SVG Circle */}
      <svg width={size} height={size} className="transform -rotate-90">
        {/* Background Circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r="120"
          stroke="#E5E9F2"
          strokeWidth="20"
          fill="none"
        />
        
        {/* Animated Progress Circle */}
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r="120"
          stroke={color}
          strokeWidth="20"
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 2, ease: "easeOut" }}
          style={{
            filter: `drop-shadow(0 0 8px ${color}40)`,
          }}
        />
      </svg>

      {/* Center Content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="text-center"
        >
          <div className={`text-6xl font-bold bg-gradient-to-r ${gradient} bg-clip-text text-transparent mb-2`}>
            {score}
          </div>
          <div className="text-gray-500 text-sm uppercase tracking-wider mb-1">
            Stress Score
          </div>
          <div className={`px-6 py-2 rounded-full bg-gradient-to-r ${gradient} text-white font-semibold text-sm shadow-lg`}>
            {level} Stress
          </div>
        </motion.div>
      </div>

      {/* Outer Glow Ring */}
      <div 
        className="absolute inset-0 rounded-full"
        style={{
          background: `radial-gradient(circle, ${color}10 0%, transparent 70%)`,
        }}
      />
    </div>
  );
}
