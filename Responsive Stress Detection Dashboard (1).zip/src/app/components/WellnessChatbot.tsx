import { useState, useEffect, useRef } from "react";
import { MessageCircle, X, Send, AlertTriangle, TrendingUp, Heart, Brain } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { chatbotEvents } from "./ChatbotTrigger";

interface Message {
  id: string;
  type: "user" | "bot" | "alert";
  content: string;
  timestamp: Date;
  alertData?: {
    stressLevel: number;
    severity: "low" | "medium" | "high";
    heartRate?: number;
    recommendation?: string;
  };
}

export function WellnessChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initial welcome message
    if (messages.length === 0) {
      addBotMessage(
        "Hi! I'm your AI wellness assistant 🌟 I'm here to help you manage stress and improve your well-being. How are you feeling today?"
      );
    }

    // Listen for external stress alerts
    const unsubscribe = chatbotEvents.subscribe((data) => {
      if (data.type === "stress_alert") {
        addStressAlert(data.stressLevel, data.severity, data.heartRate);
      }
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Simulate stress alerts
  useEffect(() => {
    if (!isOpen) return;

    const alertInterval = setInterval(() => {
      // Random chance of stress alert (15% chance every 30 seconds)
      if (Math.random() < 0.15) {
        const stressLevel = Math.floor(60 + Math.random() * 40);
        const severity = stressLevel > 80 ? "high" : stressLevel > 60 ? "medium" : "low";
        addStressAlert(stressLevel, severity);
      }
    }, 30000);

    return () => clearInterval(alertInterval);
  }, [isOpen]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const addBotMessage = (content: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      type: "bot",
      content,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, newMessage]);
  };

  const addStressAlert = (stressLevel: number, severity: "low" | "medium" | "high", heartRate?: number) => {
    const recommendations = {
      high: "Take an immediate break. Practice the 4-7-8 breathing technique.",
      medium: "Consider a short walk or 5-minute meditation.",
      low: "You're doing great! Stay hydrated and maintain your routine.",
    };

    const alertMessage: Message = {
      id: Date.now().toString(),
      type: "alert",
      content: "Stress Alert Detected",
      timestamp: new Date(),
      alertData: {
        stressLevel,
        severity,
        heartRate: heartRate || Math.floor(70 + Math.random() * 30),
        recommendation: recommendations[severity],
      },
    };

    setMessages((prev) => [...prev, alertMessage]);

    // Follow up with bot message
    setTimeout(() => {
      const followUp = severity === "high" 
        ? "I noticed your stress levels are elevated. Would you like me to guide you through a breathing exercise?"
        : "I'm monitoring your stress levels. Let me know if you need any support!";
      addBotMessage(followUp);
    }, 1000);
  };

  const handleSend = async () => {
    if (!inputValue.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");

    // Simulate bot typing
    setIsTyping(true);

    // Generate bot response based on user input
    setTimeout(() => {
      setIsTyping(false);
      const response = generateBotResponse(inputValue);
      addBotMessage(response);
    }, 1500 + Math.random() * 1000);
  };

  const generateBotResponse = (input: string): string => {
    const lowerInput = input.toLowerCase();

    // Stress-related queries
    if (lowerInput.includes("stress") || lowerInput.includes("anxious") || lowerInput.includes("worried")) {
      return "I understand you're feeling stressed. Let's work on this together. I recommend:\n\n• Take 5 deep breaths\n• Step away from screens for 10 minutes\n• Drink a glass of water\n\nWould you like me to guide you through a quick relaxation exercise?";
    }

    // Breathing exercises
    if (lowerInput.includes("breath") || lowerInput.includes("relax")) {
      return "Great choice! Let's do the 4-7-8 breathing technique:\n\n1. Breathe in through your nose for 4 seconds\n2. Hold your breath for 7 seconds\n3. Exhale slowly for 8 seconds\n4. Repeat 3-4 times\n\nThis helps activate your parasympathetic nervous system and reduce stress.";
    }

    // Sleep-related
    if (lowerInput.includes("sleep") || lowerInput.includes("tired")) {
      return "Quality sleep is crucial for stress management. Here are some tips:\n\n• Maintain a consistent sleep schedule\n• Avoid screens 1 hour before bed\n• Keep your room cool and dark\n• Try progressive muscle relaxation\n\nYour recent data shows you might benefit from earlier bedtime routines.";
    }

    // Exercise-related
    if (lowerInput.includes("exercise") || lowerInput.includes("workout")) {
      return "Exercise is excellent for stress relief! Even 15-20 minutes can help. I recommend:\n\n• Morning walks in natural light\n• Yoga or stretching\n• Light cardio when energy permits\n\nWould you like me to suggest a quick 5-minute routine?";
    }

    // Data/metrics
    if (lowerInput.includes("data") || lowerInput.includes("stats") || lowerInput.includes("report")) {
      return "I've analyzed your recent health data:\n\n📊 This Week:\n• Avg Heart Rate: 78 bpm\n• Stress Episodes: 3 high, 8 medium\n• Best Time: Mornings (lower stress)\n\nYou're trending positively! Keep up the self-care routine.";
    }

    // Positive/feeling good
    if (lowerInput.includes("good") || lowerInput.includes("great") || lowerInput.includes("happy")) {
      return "That's wonderful to hear! 🎉 Maintaining positive well-being is important. Keep up:\n\n• Your current routine\n• Regular hydration\n• Consistent sleep patterns\n\nI'm here whenever you need support!";
    }

    // Default responses
    const defaultResponses = [
      "I'm here to help you manage stress and improve your well-being. You can ask me about:\n\n• Breathing exercises\n• Stress management tips\n• Your health data analysis\n• Sleep recommendations\n\nWhat would you like to know?",
      "Based on your biometric data, I can provide personalized wellness advice. How can I assist you today?",
      "I'm monitoring your stress levels in real-time. Is there anything specific you'd like help with?",
    ];

    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const getSeverityColor = (severity: "low" | "medium" | "high") => {
    switch (severity) {
      case "high":
        return "from-red-500 to-pink-600";
      case "medium":
        return "from-yellow-500 to-orange-500";
      case "low":
        return "from-green-500 to-teal-500";
    }
  };

  return (
    <>
      {/* Floating Chat Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-r from-[#4F8EF7] to-[#00C9A7] rounded-full shadow-2xl flex items-center justify-center text-white z-50 hover:shadow-xl transition-shadow"
          >
            <MessageCircle className="w-7 h-7" />
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#FF5C5C] rounded-full flex items-center justify-center text-xs animate-pulse">
              AI
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.8 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed bottom-6 right-6 w-[420px] h-[600px] bg-white rounded-2xl shadow-2xl flex flex-col z-50 overflow-hidden border border-gray-200"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-teal-500 via-blue-500 to-purple-600 p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 backdrop-blur rounded-full flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-semibold">AI Wellness Assistant</h3>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    <span className="text-white/90 text-xs">Online • Monitoring</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="w-8 h-8 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  {message.type === "alert" && message.alertData ? (
                    // Stress Alert Card
                    <div className={`bg-gradient-to-br ${getSeverityColor(message.alertData.severity)} rounded-xl p-4 text-white shadow-lg`}>
                      <div className="flex items-start gap-3 mb-3">
                        <div className="w-10 h-10 bg-white/20 backdrop-blur rounded-full flex items-center justify-center flex-shrink-0">
                          <AlertTriangle className="w-5 h-5" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold mb-1">
                            {message.alertData.severity === "high" ? "⚠️ High Stress Detected" : 
                             message.alertData.severity === "medium" ? "⚡ Elevated Stress" : 
                             "✅ Normal Range"}
                          </h4>
                          <p className="text-white/90 text-sm mb-2">
                            {new Date(message.timestamp).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>

                      <div className="bg-white/10 backdrop-blur rounded-lg p-3 mb-3">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-white/80">Stress Level</span>
                          <span className="text-2xl font-bold">{message.alertData.stressLevel}%</span>
                        </div>
                        <div className="w-full bg-white/20 rounded-full h-2">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${message.alertData.stressLevel}%` }}
                            transition={{ duration: 1, delay: 0.2 }}
                            className="bg-white rounded-full h-2"
                          />
                        </div>
                      </div>

                      {message.alertData.heartRate && (
                        <div className="flex items-center gap-2 mb-3 text-sm">
                          <Heart className="w-4 h-4" />
                          <span>Heart Rate: {message.alertData.heartRate} bpm</span>
                        </div>
                      )}

                      <div className="bg-white/10 backdrop-blur rounded-lg p-3">
                        <p className="text-sm font-medium mb-1">💡 Recommendation:</p>
                        <p className="text-sm text-white/90">{message.alertData.recommendation}</p>
                      </div>
                    </div>
                  ) : message.type === "user" ? (
                    // User Message
                    <div className="flex justify-end">
                      <div className="bg-gradient-to-r from-teal-500 to-blue-600 text-white rounded-2xl rounded-tr-sm px-4 py-3 max-w-[80%] shadow-md">
                        <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                        <span className="text-xs text-white/70 mt-1 block">
                          {new Date(message.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                  ) : (
                    // Bot Message
                    <div className="flex gap-2">
                      <div className="w-8 h-8 bg-gradient-to-br from-teal-400 to-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <Brain className="w-4 h-4 text-white" />
                      </div>
                      <div className="bg-white rounded-2xl rounded-tl-sm px-4 py-3 max-w-[80%] shadow-md border border-gray-100">
                        <p className="text-sm text-gray-800 whitespace-pre-wrap">{message.content}</p>
                        <span className="text-xs text-gray-500 mt-1 block">
                          {new Date(message.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}

              {/* Typing Indicator */}
              {isTyping && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex gap-2"
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-teal-400 to-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <Brain className="w-4 h-4 text-white" />
                  </div>
                  <div className="bg-white rounded-2xl rounded-tl-sm px-4 py-3 shadow-md border border-gray-100">
                    <div className="flex gap-1">
                      <motion.div
                        animate={{ y: [0, -8, 0] }}
                        transition={{ repeat: Infinity, duration: 0.6, delay: 0 }}
                        className="w-2 h-2 bg-gray-400 rounded-full"
                      />
                      <motion.div
                        animate={{ y: [0, -8, 0] }}
                        transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }}
                        className="w-2 h-2 bg-gray-400 rounded-full"
                      />
                      <motion.div
                        animate={{ y: [0, -8, 0] }}
                        transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }}
                        className="w-2 h-2 bg-gray-400 rounded-full"
                      />
                    </div>
                  </div>
                </motion.div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Actions */}
            <div className="px-4 py-2 bg-white border-t border-gray-200">
              <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                {["Breathing Exercise", "View Stats", "Sleep Tips", "Stress Help"].map((action) => (
                  <button
                    key={action}
                    onClick={() => {
                      setInputValue(action);
                      setTimeout(() => handleSend(), 100);
                    }}
                    className="px-3 py-1.5 bg-gradient-to-r from-teal-50 to-blue-50 text-teal-700 rounded-full text-xs whitespace-nowrap hover:from-teal-100 hover:to-blue-100 transition-colors border border-teal-200"
                  >
                    {action}
                  </button>
                ))}
              </div>
            </div>

            {/* Input Area */}
            <div className="p-4 bg-white border-t border-gray-200">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your message..."
                  className="flex-1 px-4 py-3 bg-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 text-sm"
                />
                <button
                  onClick={handleSend}
                  disabled={!inputValue.trim()}
                  className="w-12 h-12 bg-gradient-to-r from-teal-500 to-blue-600 rounded-xl flex items-center justify-center text-white shadow-md hover:shadow-lg transition-shadow disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}