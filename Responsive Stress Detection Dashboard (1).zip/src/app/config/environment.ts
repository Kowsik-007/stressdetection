// Environment configuration
// This file helps manage different environments (development, production)

interface Config {
  apiBaseUrl: string;
  isProduction: boolean;
  autoRefreshInterval: number; // in milliseconds
  enableMockData: boolean;
}

// Development configuration
const development: Config = {
  apiBaseUrl: "http://localhost:8000/api", // Your local backend URL
  isProduction: false,
  autoRefreshInterval: 5000, // 5 seconds
  enableMockData: true, // Set to false when backend is ready
};

// Production configuration
const production: Config = {
  apiBaseUrl: "https://your-production-api.com/api", // Your production backend URL
  isProduction: true,
  autoRefreshInterval: 5000, // 5 seconds
  enableMockData: false, // Always use real data in production
};

// Determine current environment
const isProduction = import.meta.env.MODE === "production";

// Export the appropriate configuration
export const config: Config = isProduction ? production : development;

// Helper functions
export const getApiUrl = (endpoint: string): string => {
  return `${config.apiBaseUrl}${endpoint}`;
};

export const shouldUseMockData = (): boolean => {
  return config.enableMockData;
};

export const getRefreshInterval = (): number => {
  return config.autoRefreshInterval;
};
