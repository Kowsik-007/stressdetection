import { createBrowserRouter } from "react-router";
import { Login } from "./pages/Login";
import { Dashboard } from "./pages/Dashboard";
import { History } from "./pages/History";
import { Alerts } from "./pages/Alerts";
import { Settings } from "./pages/Settings";
import { RelaxationGames } from "./pages/RelaxationGames";
import { Layout } from "./components/Layout";

export const router = createBrowserRouter([
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: "history", Component: History },
      { path: "alerts", Component: Alerts },
      { path: "games", Component: RelaxationGames },
      { path: "settings", Component: Settings },
    ],
  },
]);