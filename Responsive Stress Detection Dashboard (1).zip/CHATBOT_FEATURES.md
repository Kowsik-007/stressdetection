# 🤖 AI Wellness Chatbot - Feature Documentation

## Overview

The AI Wellness Chatbot is an intelligent conversational assistant integrated into the stress monitoring dashboard. It provides real-time stress alerts, personalized wellness advice, and interactive health guidance.

## 🎯 Key Features

### 1. **Real-Time Stress Alert Cards**

The chatbot automatically receives and displays stress alerts when the system detects elevated stress levels.

#### Alert Card Components:
- **Severity Indicator**: Color-coded headers (⚠️ High, ⚡ Medium, ✅ Low)
- **Stress Percentage**: Large display with animated progress bar
- **Heart Rate**: Real-time BPM reading
- **Timestamp**: When the alert was generated
- **Recommendations**: Context-specific wellness advice

#### Color Coding:
```
High Stress (71-100%):    Red to Pink gradient
Medium Stress (41-70%):   Yellow to Orange gradient
Low Stress (0-40%):       Green to Teal gradient
```

#### Example Alert:
```
⚠️ High Stress Detected
Time: 2:30 PM

Stress Level: 85%
Heart Rate: 95 bpm

💡 Recommendation:
Take an immediate break. Practice the 4-7-8 breathing technique.
```

### 2. **Animated Typing Indicator**

Professional typing animation that simulates natural conversation flow.

**Features:**
- Three bouncing dots animation
- Smooth fade-in/fade-out transitions
- Appears while bot "thinks" (1.5-2.5 seconds)
- Matches chatbot avatar styling

**Animation Details:**
- Dot size: 8px
- Bounce height: 8px
- Animation cycle: 0.6 seconds
- Staggered timing: 0.2s delay per dot

### 3. **Smart Conversational AI**

Natural language understanding with context-aware responses.

#### Supported Topics:

**Stress Management**
- Keywords: "stress", "anxious", "worried"
- Response: Breathing exercises, break suggestions, hydration tips

**Breathing Exercises**
- Keywords: "breath", "relax"
- Response: 4-7-8 breathing technique with step-by-step instructions

**Sleep Quality**
- Keywords: "sleep", "tired"
- Response: Sleep hygiene tips, bedtime routines

**Exercise Recommendations**
- Keywords: "exercise", "workout"
- Response: Light cardio, yoga, stretching suggestions

**Data Analysis**
- Keywords: "data", "stats", "report"
- Response: Weekly summary, trends, insights

**Positive Reinforcement**
- Keywords: "good", "great", "happy"
- Response: Encouragement and maintenance tips

### 4. **Interactive UI Elements**

#### Floating Chat Button
- **Position**: Fixed bottom-right corner
- **Size**: 64x64px circular button
- **Gradient**: Teal to Blue (matching app theme)
- **Badge**: "AI" indicator with pulse animation
- **Hover Effect**: Scales to 110%
- **Animation**: Spring transition (damping: 25, stiffness: 300)

#### Chat Window
- **Dimensions**: 420px × 600px
- **Position**: Bottom-right, 24px margin
- **Border Radius**: 16px (rounded corners)
- **Shadow**: Large shadow for depth
- **Animation**: Slide up with scale from 0.8 to 1.0

#### Header
- **Gradient**: Teal → Blue → Purple (medical theme)
- **Status Indicator**: Green pulsing dot
- **Text**: "Online • Monitoring"
- **Avatar**: Brain icon in gradient circle

### 5. **Quick Action Buttons**

Pre-defined queries for instant access to common features:

| Button | Action | Response Type |
|--------|--------|---------------|
| 🫁 Breathing Exercise | Triggers breathing guide | Step-by-step instructions |
| 📊 View Stats | Shows health analytics | Weekly data summary |
| 😴 Sleep Tips | Provides sleep advice | Sleep hygiene guide |
| 🆘 Stress Help | Emergency stress help | Immediate coping strategies |

**Styling:**
- Gradient background: Teal-50 to Blue-50
- Border: Teal-200
- Text: Teal-700
- Pills: Rounded full
- Scrollable horizontally on mobile

### 6. **Message Types**

#### User Messages
- **Alignment**: Right-aligned
- **Background**: Gradient (Teal to Blue)
- **Color**: White text
- **Shape**: Rounded bubble with small tail (top-right)
- **Timestamp**: Light opacity, below message

#### Bot Messages
- **Alignment**: Left-aligned
- **Background**: White with gray border
- **Color**: Dark gray text
- **Avatar**: Gradient brain icon
- **Shape**: Rounded bubble with small tail (top-left)
- **Timestamp**: Gray, below message

#### Alert Messages
- **Full Width**: Centered in chat
- **Background**: Severity-based gradient
- **Content**: Structured card layout
- **Animation**: Progress bar fills on load
- **Interactive**: No tail, card-based design

### 7. **Gradient Accents (Healthcare SaaS Theme)**

All gradients match the healthcare/medical-tech aesthetic:

```css
/* Primary Chatbot Button */
from-teal-500 to-blue-600

/* Chat Header */
from-teal-500 via-blue-500 to-purple-600

/* User Messages */
from-teal-500 to-blue-600

/* Bot Avatar */
from-teal-400 to-blue-500

/* High Stress Alert */
from-red-500 to-pink-600

/* Medium Stress Alert */
from-yellow-500 to-orange-500

/* Low Stress Alert */
from-green-500 to-teal-500

/* Quick Actions */
from-teal-50 to-blue-50
```

## 🔧 Technical Implementation

### Component Structure

```
WellnessChatbot/
├── Floating Button (AnimatePresence)
├── Chat Window (Motion.div)
│   ├── Header
│   │   ├── Avatar
│   │   ├── Title & Status
│   │   └── Close Button
│   ├── Messages Area
│   │   ├── Alert Cards
│   │   ├── User Messages
│   │   ├── Bot Messages
│   │   └── Typing Indicator
│   ├── Quick Actions
│   └── Input Area
│       ├── Text Input
│       └── Send Button
```

### State Management

```typescript
const [isOpen, setIsOpen] = useState(false);          // Chat visibility
const [messages, setMessages] = useState<Message[]>([]);  // Message history
const [inputValue, setInputValue] = useState("");     // User input
const [isTyping, setIsTyping] = useState(false);      // Typing animation
```

### Event System

The chatbot listens for external stress alerts using a custom event emitter:

```typescript
// Subscribe to stress alerts
chatbotEvents.subscribe((data) => {
  if (data.type === "stress_alert") {
    addStressAlert(data.stressLevel, data.severity, data.heartRate);
  }
});

// Send alert from Dashboard
sendStressAlertToChat(stressLevel, heartRate);
```

### Auto-Scroll Behavior

Messages automatically scroll to bottom when:
- New message arrives
- Typing indicator appears
- Alert card is added
- Chat opens

```typescript
const scrollToBottom = () => {
  messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
};
```

## 🎨 Design Specifications

### Typography
- **Headers**: 16px semibold
- **Body Text**: 14px regular
- **Timestamps**: 12px light
- **Quick Actions**: 12px medium

### Spacing
- **Message Padding**: 16px
- **Message Gap**: 16px
- **Card Padding**: 16-24px
- **Input Padding**: 12px

### Colors (Light Theme)
- **Background**: Gray-50 (#F9FAFB)
- **Message BG**: White (#FFFFFF)
- **Border**: Gray-200 (#E5E7EB)
- **Text**: Gray-800 (#1F2937)
- **Placeholder**: Gray-400 (#9CA3AF)

### Animations
- **Typing Dots**: Bounce 0.6s infinite
- **Message Fade**: 0.3s ease-in-out
- **Chat Open**: Spring (damping: 25)
- **Button Hover**: Scale 1.1
- **Progress Bar**: 1s ease-out

## 📊 Integration with Dashboard

### Automatic Stress Alerts

When the dashboard detects stress levels ≥ 60%, it automatically:
1. Sends alert to chatbot via event emitter
2. Chatbot displays color-coded alert card
3. Bot follows up with personalized message
4. Provides actionable recommendations

### Flow Diagram

```
Dashboard (every 5s)
    ↓
Fetch Sensor Data
    ↓
Stress ≥ 60% ?
    ↓ Yes
Send to Chatbot
    ↓
Display Alert Card
    ↓
Show Typing Indicator (1s delay)
    ↓
Bot Follow-up Message
```

## 🚀 Usage Examples

### Opening the Chat
1. Click floating AI button (bottom-right)
2. Chat slides up with animation
3. Welcome message appears
4. Quick actions ready

### Sending a Message
1. Type in input field
2. Press Enter or click Send button
3. Message appears on right
4. Typing indicator shows
5. Bot responds after 1.5-2.5s

### Receiving a Stress Alert
1. Dashboard detects high stress (85%)
2. Alert card appears in chat
3. Shows: stress %, heart rate, time
4. Provides recommendation
5. Bot asks if help is needed

### Using Quick Actions
1. Scroll quick action buttons
2. Click "Breathing Exercise"
3. Input auto-fills
4. Message sends automatically
5. Receive detailed guide

## 🔒 Privacy & Data

- Messages stored in component state (not persisted)
- No external API calls (mock responses)
- User data remains in browser localStorage
- Chat history clears on component unmount
- No sensitive health data transmitted

## 🎯 Future Enhancements

1. **Voice Input/Output**
   - Speech-to-text for messages
   - Text-to-speech for responses

2. **Personalization**
   - Learn user preferences
   - Custom response patterns
   - Remember conversation context

3. **Advanced Analytics**
   - Mood tracking over time
   - Stress pattern recognition
   - Predictive wellness alerts

4. **Integration**
   - Connect to real AI/ML backend
   - Natural language processing API
   - Sentiment analysis

5. **Rich Media**
   - Video tutorials for exercises
   - Audio-guided meditation
   - Interactive wellness games

## 📱 Responsive Design

### Mobile (< 640px)
- Chat width: calc(100vw - 32px)
- Reduced padding: 12px
- Smaller avatars: 32px
- Font size: 13px

### Tablet (640-1024px)
- Chat width: 400px
- Standard padding
- Standard avatars: 40px
- Font size: 14px

### Desktop (> 1024px)
- Chat width: 420px
- Enhanced shadows
- Full feature set
- Font size: 14px

## 🆘 Troubleshooting

### Chat Not Opening
- Check z-index conflicts
- Verify React Router setup
- Ensure Motion is installed

### Alerts Not Appearing
- Verify event emitter connection
- Check stress threshold (≥60%)
- Confirm chatbotEvents imported

### Animations Choppy
- Reduce animation complexity
- Check browser performance
- Disable motion for accessibility

---

**Built with 💙 for better mental health**
