# 🚀 Quick Reference Card

## System At-A-Glance

### 🎯 Project Type
**Behavioral Pattern-Based AI Stress Detection System**  
No hardware sensors • Privacy-focused • AI-powered

---

## 🎨 Color Palette

```
Primary:  #4F8EF7  (Blue)
Accent:   #00C9A7  (Teal)
Alert:    #FF5C5C  (Red)
Purple:   #8B7FE6  (Soft Purple)
Warning:  #FFA94D  (Yellow)
BG:       #F5F9FF  (Light Blue)
```

---

## 📊 Stress Calculation

### Inputs:
- Sleep Hours (0-24h)
- Work Hours (0-24h)
- Screen Time (0-24h)
- Mood (Happy/Neutral/Anxious/Tired)

### Output:
- Stress Score (0-100)
- Low (0-40) 🟢
- Medium (41-70) 🟡
- High (71-100) 🔴

---

## 📱 Main Pages

| Page | Purpose | Key Features |
|------|---------|--------------|
| **Dashboard** | Main interface | Stress meter, input form, insights |
| **Stress Analysis** | History | Trends, charts, patterns |
| **AI Wellness** | Chatbot | Real-time alerts, recommendations |
| **Settings** | Preferences | Profile, notifications, data |

---

## 🧩 Key Components

```
StressMeter.tsx      → Circular gauge (280px)
WellnessChatbot.tsx  → AI chat widget (420×600px)
ChatbotTrigger.tsx   → Event emitter
Dashboard.tsx        → Main page
Settings.tsx         → Settings page
```

---

## 🎨 Design Tokens

### Spacing:
- xs: 4px
- sm: 8px
- md: 16px
- lg: 24px
- xl: 32px

### Radius:
- sm: 8px
- md: 12px
- lg: 16px
- full: 9999px

### Shadows:
- sm: shadow-sm
- md: shadow-lg
- lg: shadow-xl
- xl: shadow-2xl

---

## 🚀 Quick Commands

```bash
# Install
npm install

# Run
npm run dev

# Build
npm run build

# Open
http://localhost:5173

# Login
demo@example.com / password123
```

---

## 📦 Tech Stack

```
React        18.3.1
React Router 7.13.0
Tailwind CSS 4.1.12
Recharts     2.15.2
Motion       12.23.24
Axios        1.13.5
Lucide React 0.487.0
```

---

## 🎯 Gradient Recipes

```css
/* Primary Button */
from-[#4F8EF7] to-[#00C9A7]

/* Dashboard BG */
from-[#F5F9FF] via-white to-[#F0F4FF]

/* Insights Panel */
from-[#4F8EF7] to-[#8B7FE6]

/* Chatbot Header */
from-teal-500 via-blue-500 to-purple-600

/* Sleep Card */
from-blue-400 to-blue-600

/* Work Card */
from-purple-400 to-purple-600

/* Screen Card */
from-teal-400 to-emerald-600

/* Mood Card */
from-orange-400 to-yellow-500

/* Low Stress */
from-emerald-400 to-teal-500

/* Med Stress */
from-yellow-400 to-orange-500

/* High Stress */
from-red-400 to-pink-500
```

---

## 🔧 Configuration Files

```
/src/styles/theme.css       → Color variables
/src/app/routes.ts          → Navigation routes
/src/app/services/api.ts    → API endpoints
/package.json               → Dependencies
```

---

## 📊 Metric Cards

| Icon | Title | Gradient | Range |
|------|-------|----------|-------|
| 🌙 | Sleep | Blue | 0-24h |
| ☕ | Work | Purple | 0-24h |
| 📱 | Screen | Teal | 0-24h |
| 😊 | Mood | Orange | 4 levels |

---

## 🤖 Chatbot Features

- ✅ Real-time stress alerts
- ✅ Animated typing indicator
- ✅ Quick action buttons
- ✅ Smart conversation
- ✅ Color-coded alerts
- ✅ Gradient UI
- ✅ Smooth animations

---

## 📈 Chart Types

| Chart | Library | Data | Purpose |
|-------|---------|------|---------|
| Area | Recharts | 7-day | Trends |
| Circular | SVG | 0-100 | Score |

---

## 🎭 Animation Library

```typescript
import { motion } from "motion/react"

<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.5 }}
>
  Content
</motion.div>
```

---

## 📝 Form Fields

```typescript
// Mood Dropdown
<select>
  <option>😊 Happy</option>
  <option>😐 Neutral</option>
  <option>😰 Anxious</option>
  <option>😴 Tired</option>
</select>

// Number Input
<input 
  type="number" 
  min="0" 
  max="24" 
  step="0.5"
/>
```

---

## 🔐 Authentication

```typescript
// Mock login (any credentials work)
localStorage.setItem("user", JSON.stringify({
  email: formData.email,
  userId: "user123"
}))
```

---

## 📱 Responsive Grid

```
Desktop (>1024px):  4 columns
Tablet (640-1024):  2 columns
Mobile (<640px):    1 column
```

---

## 🎨 Status Colors

| Status | Range | Color | Hex |
|--------|-------|-------|-----|
| Low | 0-40 | Green | #00C9A7 |
| Medium | 41-70 | Yellow | #FFA94D |
| High | 71-100 | Red | #FF5C5C |

---

## 🧮 Algorithm

```javascript
score = 0
score += sleepImpact(0-30)
score += workImpact(0-30)
score += screenImpact(0-20)
score += moodImpact(0-20)
final = min(100, max(0, score))
```

---

## 📁 File Structure

```
/src/app/
  components/
    ├── StressMeter.tsx
    ├── WellnessChatbot.tsx
    ├── ChatbotTrigger.tsx
    └── Layout.tsx
  pages/
    ├── Dashboard.tsx
    ├── History.tsx
    ├── Alerts.tsx
    ├── Settings.tsx
    └── Login.tsx
  routes.ts
  services/
    └── api.ts
```

---

## 🎯 Key Features

✅ Circular stress meter  
✅ Behavioral input form  
✅ AI insights panel  
✅ Trend chart  
✅ Recommendation cards  
✅ AI chatbot  
✅ Settings page  
✅ Responsive design  
✅ Dark mode support  
✅ Smooth animations  

---

## 📚 Documentation

- `README.md` - Main overview
- `NEW_SYSTEM_GUIDE.md` - Complete guide
- `DESIGN_CHANGES.md` - What changed
- `UI_SHOWCASE.md` - Visual reference
- `QUICK_REFERENCE.md` - This file
- `CHATBOT_FEATURES.md` - Chatbot details
- `QUICKSTART.md` - Getting started
- `API_INTEGRATION_GUIDE.md` - Backend

---

## 🎓 Project Info

**Title:** Behavioral Pattern-Based Early Stress & Burnout Detection System Using Deep Learning

**Type:** Final Year Engineering Project

**Year:** 2026

**Approach:** Non-invasive behavioral analysis

---

## 🔗 Quick Links

```
Dashboard:  http://localhost:5173/
Analysis:   http://localhost:5173/history
Chatbot:    http://localhost:5173/alerts
Settings:   http://localhost:5173/settings
```

---

## ⚡ Performance Tips

- Use `Motion` for animations
- Lazy load images
- Debounce form inputs
- Memoize calculations
- Use `ResponsiveContainer` for charts

---

## 🐛 Debug Checklist

- [ ] Check console (F12)
- [ ] Verify user in localStorage
- [ ] Check API endpoint configuration
- [ ] Test responsive breakpoints
- [ ] Validate form inputs
- [ ] Test dark mode

---

## 📊 Data Flow

```
User Input → Calculate → Display
     ↓          ↓          ↓
  [Form]    [Score]   [Insights]
     ↓          ↓          ↓
  Backend   AI Model   Chatbot
(Optional)
```

---

## 🎨 Icon Library

Using `lucide-react`:
- Activity, Brain, Bell, Settings
- Moon, Sun, User, LogOut
- Heart, Coffee, Smartphone, Smile
- TrendingUp, AlertTriangle, Send

---

## 💡 Pro Tips

1. Use gradient backgrounds for modern feel
2. Add micro-animations on hover
3. Keep color palette consistent
4. Use 8px spacing grid
5. Test on mobile devices
6. Add loading states
7. Handle errors gracefully
8. Keep animations subtle

---

## 🎯 Success Metrics

- ✅ Modern UI implemented
- ✅ Behavioral inputs working
- ✅ Stress calculation accurate
- ✅ AI chatbot integrated
- ✅ Responsive on all devices
- ✅ No console errors
- ✅ Documentation complete

---

## 📝 Version

**Current Version:** 2.0.0 (Behavioral Edition)  
**Last Updated:** February 27, 2026  
**Status:** ✅ Production Ready

---

**Print this card for quick reference during development!**
