# API Integration Guide

This document provides detailed information for integrating the frontend with your backend API.

## 🔗 Quick Setup

1. Open `/src/app/services/api.ts`
2. Replace `"http://your-api-url"` with your actual backend URL
3. Ensure CORS is enabled on your backend

## 📡 API Endpoints

### 1. Authentication

#### Login
```http
POST /login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "securepassword123"
}
```

**Expected Response:**
```json
{
  "success": true,
  "user": {
    "userId": "user123",
    "email": "user@example.com",
    "name": "John Doe"
  },
  "token": "jwt_token_here"
}
```

#### Register
```http
POST /register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "user@example.com",
  "password": "securepassword123"
}
```

**Expected Response:**
```json
{
  "success": true,
  "message": "User registered successfully",
  "userId": "user123"
}
```

### 2. Sensor Data

#### Send Sensor Data
```http
POST /sensor-data
Content-Type: application/json
Authorization: Bearer {token}

{
  "userId": "user123",
  "heartRate": 75,
  "gsr": 3.2,
  "temperature": 36.5,
  "timestamp": "2026-02-21T10:30:00Z"
}
```

**Expected Response:**
```json
{
  "success": true,
  "message": "Sensor data recorded",
  "dataId": "sensor_data_123"
}
```

### 3. Stress Prediction

#### Get Stress Prediction
```http
GET /predict/{userId}
Authorization: Bearer {token}
```

**Expected Response:**
```json
{
  "userId": "user123",
  "heartRate": 85,
  "gsr": 4.5,
  "temperature": 37.2,
  "stressLevel": "High",
  "probability": 78,
  "timestamp": "2026-02-21T10:30:00Z",
  "recommendations": [
    "Take a break",
    "Practice deep breathing",
    "Stay hydrated"
  ]
}
```

**Stress Level Values:**
- `"Low"` - Probability: 0-40%
- `"Medium"` - Probability: 41-70%
- `"High"` - Probability: 71-100%

### 4. Historical Data

#### Get User History
```http
GET /history/{userId}
Authorization: Bearer {token}

Query Parameters:
- startDate (optional): YYYY-MM-DD
- endDate (optional): YYYY-MM-DD
- limit (optional): number
```

**Expected Response:**
```json
{
  "userId": "user123",
  "history": [
    {
      "date": "2026-02-21",
      "avgHeartRate": 78,
      "avgGsr": 3.5,
      "avgTemperature": 36.8,
      "stressLevel": "Medium",
      "riskPercentage": 55,
      "readings": 48
    },
    {
      "date": "2026-02-20",
      "avgHeartRate": 72,
      "avgGsr": 2.8,
      "avgTemperature": 36.5,
      "stressLevel": "Low",
      "riskPercentage": 25,
      "readings": 52
    }
  ]
}
```

## 🔐 Authentication

The frontend uses JWT token-based authentication:

1. After successful login/register, store the token in the response
2. The API service automatically attaches the token to subsequent requests
3. Token is stored in localStorage with user data

**Token Storage Format:**
```json
{
  "userId": "user123",
  "email": "user@example.com",
  "token": "jwt_token_here"
}
```

## 🛠️ Enabling Real API Calls

### Step 1: Configure API Base URL

In `/src/app/services/api.ts`:
```typescript
const API_BASE_URL = "https://your-backend-api.com/api";
```

### Step 2: Update Login Page

In `/src/app/pages/Login.tsx`, uncomment the API call:
```typescript
// Replace this line:
// const response = await axios.post(`http://your-api-url${endpoint}`, formData);

// With this:
const response = await axios.post(`${endpoint}`, formData);

// And update user storage:
localStorage.setItem("user", JSON.stringify({
  email: formData.email,
  userId: response.data.user.userId,
  token: response.data.token
}));
```

### Step 3: Update Dashboard

In `/src/app/pages/Dashboard.tsx`, uncomment the API call:
```typescript
// Replace mock data with:
const user = JSON.parse(localStorage.getItem("user") || "{}");
const response = await axios.get(`/predict/${user.userId}`);
setSensorData({
  heartRate: response.data.heartRate,
  gsr: response.data.gsr,
  temperature: response.data.temperature,
  stressLevel: response.data.stressLevel,
  probability: response.data.probability,
});
```

### Step 4: Update History Page

In `/src/app/pages/History.tsx`, uncomment the API call:
```typescript
// Replace mock data with:
const user = JSON.parse(localStorage.getItem("user") || "{}");
const response = await axios.get(`/history/${user.userId}`);
setHistoryData(response.data.history);
```

## 🌐 CORS Configuration

Ensure your backend allows requests from the frontend domain:

```python
# Example for Flask (Python)
from flask_cors import CORS

app = Flask(__name__)
CORS(app, origins=["http://localhost:5173", "https://your-frontend-domain.com"])
```

```javascript
// Example for Express (Node.js)
const cors = require('cors');

app.use(cors({
  origin: ['http://localhost:5173', 'https://your-frontend-domain.com']
}));
```

## 🔄 Real-Time Updates

The dashboard refreshes data every 5 seconds. To optimize:

1. **Option 1: Polling (Current)**
   - Frontend calls `/predict/{userId}` every 5 seconds
   - Simple to implement
   - Higher server load

2. **Option 2: WebSockets (Recommended)**
   - Install `socket.io-client`
   - Implement WebSocket connection
   - Backend pushes updates when new data arrives
   - Lower latency, better performance

### WebSocket Integration Example

```typescript
import io from 'socket.io-client';

const socket = io('http://your-websocket-url');

socket.on('sensorUpdate', (data) => {
  setSensorData(data);
});
```

## 📊 Data Format Specifications

### Heart Rate
- **Unit:** beats per minute (bpm)
- **Type:** Integer
- **Normal Range:** 60-100 bpm
- **Stress Indicator:** >90 bpm

### GSR (Galvanic Skin Response)
- **Unit:** microsiemens (µS)
- **Type:** Float (1 decimal)
- **Normal Range:** 1-5 µS
- **Stress Indicator:** >3.5 µS

### Temperature
- **Unit:** Celsius (°C)
- **Type:** Float (1 decimal)
- **Normal Range:** 36.1-37.2°C
- **Stress Indicator:** >37.0°C

## 🐛 Error Handling

The frontend expects standard HTTP status codes:

- **200:** Success
- **201:** Created
- **400:** Bad Request (validation errors)
- **401:** Unauthorized (invalid token)
- **404:** Not Found
- **500:** Internal Server Error

**Error Response Format:**
```json
{
  "success": false,
  "error": "Error message here",
  "code": "ERROR_CODE"
}
```

## 🧪 Testing

### Mock Data Mode (Current)
- Frontend runs with simulated sensor data
- No backend required for testing UI/UX
- Random data generation every 5 seconds

### Testing with Real API
1. Set up backend server
2. Update API_BASE_URL
3. Uncomment API calls
4. Test each endpoint individually
5. Monitor network tab in browser DevTools

## 📱 Mobile/IoT Integration

For IoT devices sending sensor data:

```http
POST /sensor-data
Content-Type: application/json

{
  "deviceId": "iot_device_001",
  "userId": "user123",
  "heartRate": 75,
  "gsr": 3.2,
  "temperature": 36.5,
  "timestamp": "2026-02-21T10:30:00Z"
}
```

## 🔒 Security Best Practices

1. **Always use HTTPS in production**
2. **Implement rate limiting on API endpoints**
3. **Validate and sanitize all inputs**
4. **Use secure password hashing (bcrypt, argon2)**
5. **Implement JWT token expiration**
6. **Add refresh token mechanism**
7. **Log all authentication attempts**
8. **Implement API key rotation**

## 📈 Performance Optimization

1. **Caching:** Cache prediction results for 1-2 seconds
2. **Compression:** Enable gzip/brotli compression
3. **Pagination:** Implement pagination for history data
4. **Database Indexing:** Index userId, timestamp fields
5. **CDN:** Use CDN for static assets

## 🆘 Troubleshooting

### CORS Errors
- Enable CORS on backend
- Check allowed origins
- Verify request headers

### 401 Unauthorized
- Check token validity
- Verify token format
- Ensure Authorization header is set

### Slow Response Times
- Check server load
- Optimize database queries
- Implement caching
- Use connection pooling

## 📞 Support

For integration support, contact the development team with:
- Error logs
- Network request/response data
- Environment details
- Steps to reproduce

---

**Happy Integrating! 🚀**
