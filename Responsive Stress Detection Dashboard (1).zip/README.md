# 🧠 AI-Powered Behavioral Stress Detection System

**Final Year Engineering Project 2026**

A modern, clean, AI-powered web dashboard that estimates stress levels using behavioral pattern analysis instead of hardware sensors.

![Status](https://img.shields.io/badge/Status-Active-success)
![React](https://img.shields.io/badge/React-18.3.1-blue)
![TailwindCSS](https://img.shields.io/badge/TailwindCSS-4.1.12-38B2AC)
![License](https://img.shields.io/badge/License-Educational-orange)

---

## 🌟 Project Overview

### Title
**Behavioral Pattern-Based Early Stress & Burnout Detection System Using Deep Learning**

### Description
This system analyzes behavioral inputs (sleep hours, mood, work hours, screen time) to predict stress levels using AI-powered algorithms. Unlike traditional IoT sensor-based systems, this approach focuses on privacy-friendly, self-reported behavioral data to provide personalized wellness insights.

### Key Innovation
❌ **No hardware sensors required**  
✅ **Behavioral pattern analysis**  
✅ **Privacy-focused design**  
✅ **AI-powered recommendations**

---

## 🎨 Design Features

### Visual Style
- **Calming Color Palette**: Blue (#4F8EF7), Teal (#00C9A7), Soft Purple (#8B7FE6)
- **Modern Healthcare Aesthetic**: Professional medical-tech interface
- **Clean & Minimal**: Rounded cards with soft shadows
- **Smooth Animations**: Motion-based transitions
- **Glassmorphism Effects**: Subtle gradient backgrounds

### UI Highlights
- 🎯 **Large Circular Stress Meter** (0-100 scale)
- 📊 **Behavioral Metric Cards** (Sleep, Work, Screen, Mood)
- 🤖 **AI Wellness Chatbot** with real-time alerts
- 📈 **Interactive Trend Charts** (7-day analysis)
- 💡 **Smart Recommendations** (Meditation, Hydration, Movement)

---

## 🛠️ Technology Stack

- **Frontend Framework:** React.js 18.3.1
- **Routing:** React Router 7.13.0
- **Styling:** Tailwind CSS 4.1.12
- **Charts:** Recharts 2.15.2
- **Icons:** Lucide React 0.487.0
- **HTTP Client:** Axios 1.13.5
- **Animations:** Motion 12.23.24 (formerly Framer Motion)
- **Build Tool:** Vite 6.3.5

---

## 📱 Main Features

### 1. **Dashboard**
- **Circular Stress Meter**: Real-time stress score (0-100) with color-coded status
  - 🟢 Low (0-40): Green gradient
  - 🟡 Medium (41-70): Yellow gradient
  - 🔴 High (71-100): Red gradient
- **Behavioral Input Form**:
  - Mood dropdown (😊 Happy, 😐 Neutral, 😰 Anxious, 😴 Tired)
  - Sleep hours input (last night)
  - Work hours input (today)
  - Screen time input (today)
- **Metric Cards**: Beautiful gradient cards showing current values
- **AI Insights Panel**: Sleep quality, work balance, screen warnings, mood trends
- **Stress Trend Chart**: 7-day area chart with gradient fill
- **Wellness Recommendations**: Meditation, hydration, movement tips

### 2. **Stress Analysis**
- Historical stress data visualization
- Weekly trends and patterns
- Behavioral correlation analysis
- Downloadable reports

### 3. **AI Wellness Assistant** 🤖
- **Floating Chat Widget** (bottom-right corner)
- **Real-Time Stress Alerts**:
  - Automatic notifications when stress ≥60%
  - Color-coded alert cards with severity levels
  - Stress percentage with animated progress bar
  - Personalized recommendations
- **Animated Typing Indicator**: Three bouncing dots
- **Smart Conversational Interface**:
  - Natural language understanding
  - Context-aware responses
  - Personalized wellness advice
- **Interactive Features**:
  - Quick action buttons (Breathing Exercise, View Stats, Sleep Tips, Stress Help)
  - Gradient healthcare-themed UI
  - Smooth animations and transitions
- **Wellness Guidance**:
  - Breathing exercise instructions (4-7-8 technique)
  - Sleep quality tips
  - Exercise recommendations
  - Data analysis and insights
  - Stress management strategies

### 4. **Settings**
- Profile management
- Notification preferences
- Data retention controls
- Theme customization
- About information

---

## 🧮 Stress Calculation Algorithm

### Input Parameters

| Parameter | Range | Optimal | Impact |
|-----------|-------|---------|--------|
| Sleep Hours | 0-24h | 7-9h | 0-30 points |
| Work Hours | 0-24h | ≤8h | 0-30 points |
| Screen Time | 0-24h | <6h | 0-20 points |
| Mood | 4 levels | Happy | 0-20 points |

### Calculation Logic

```javascript
baseScore = 0

// Sleep Factor (0-30 points)
if (sleepHours < 6) baseScore += 25
else if (sleepHours < 7) baseScore += 15
else if (sleepHours > 9) baseScore += 10

// Work Hours Factor (0-30 points)
if (workHours > 10) baseScore += 30
else if (workHours > 8) baseScore += 20
else if (workHours < 4) baseScore += 15

// Screen Time Factor (0-20 points)
if (screenTime > 8) baseScore += 20
else if (screenTime > 6) baseScore += 12

// Mood Factor (0-20 points)
moodScores = {
  Happy: 0,
  Neutral: 10,
  Anxious: 20,
  Tired: 15
}
baseScore += moodScores[mood]

finalScore = min(100, max(0, baseScore))
```

### Classification

- **Low Stress (0-40)**: Healthy state, minimal intervention needed
- **Medium Stress (41-70)**: Moderate concern, lifestyle adjustments recommended
- **High Stress (71-100)**: Alert state, immediate wellness actions needed

---

## 🚀 Quick Start

### Installation

```bash
# Clone the repository
git clone <repository-url>

# Navigate to project directory
cd stress-detection-system

# Install dependencies
npm install
# or
pnpm install
```

### Run Development Server

```bash
npm run dev
# or
pnpm dev
```

The app will open at `http://localhost:5173`

### Login

Use any credentials (mock authentication):
```
Email: demo@example.com
Password: password123
```

---

## 📖 Usage Guide

### Step 1: Input Behavioral Data
1. Navigate to Dashboard
2. Fill in the input form:
   - Select your current mood
   - Enter sleep hours (last night)
   - Enter work hours (today)
   - Enter screen time (today)

### Step 2: Calculate Stress
1. Click "Calculate Stress Level" button
2. AI analyzes your behavioral patterns
3. View results on circular stress meter

### Step 3: Review Insights
1. Check AI-powered insights panel
2. Review sleep quality assessment
3. Monitor work-life balance status
4. See screen time warnings
5. Track mood trends

### Step 4: Interact with AI Assistant
1. Click floating AI button (bottom-right)
2. Ask wellness questions
3. Get personalized recommendations
4. Try quick actions for exercises

### Step 5: Monitor Trends
1. View 7-day stress trend chart
2. Identify patterns over time
3. Adjust behaviors based on data

---

## 🔗 API Integration (Optional)

### Backend Endpoints

```typescript
// Calculate stress from behavioral data
POST /api/calculate-stress
Body: {
  sleepHours: number,
  workHours: number,
  screenTime: number,
  mood: string
}
Response: {
  stressScore: number,
  insights: object
}

// Get historical data
GET /api/stress-history?days=7

// Save behavioral entry
POST /api/behavioral-data
```

### Configuration

Edit `/src/app/services/api.ts`:
```typescript
const API_BASE_URL = "http://your-backend-url:8000/api";
```

---

## 📊 Project Structure

```
/src/app/
├── components/
│   ├── StressMeter.tsx        # Circular stress gauge
│   ├── WellnessChatbot.tsx    # AI chat widget
│   ├── ChatbotTrigger.tsx     # Event emitter
│   └── Layout.tsx             # Main layout wrapper
├── pages/
│   ├── Dashboard.tsx          # Main dashboard
│   ├── History.tsx            # Stress analysis
│   ├── Alerts.tsx             # AI wellness
│   ├── Settings.tsx           # User settings
│   └── Login.tsx              # Authentication
├── routes.ts                  # App routing
└── services/
    └── api.ts                 # API configuration
```

---

## 🎓 Academic Context

### Final Year Engineering Project

**Objectives:**
1. Develop a non-invasive stress detection system
2. Analyze behavioral patterns using AI/ML
3. Provide actionable wellness recommendations
4. Create a user-friendly healthcare interface

**Technologies:**
- Frontend: React, Tailwind CSS, Motion
- Data Visualization: Recharts
- AI/ML: Deep Learning (backend integration ready)
- Design: Healthcare SaaS aesthetic

**Key Differentiators:**
- ❌ No hardware/IoT sensors required
- ✅ Privacy-friendly (self-reported data)
- ✅ Cost-effective solution
- ✅ Universally accessible
- ✅ Real-time AI recommendations

---

## 📈 Future Enhancements

1. **Advanced ML Models**
   - LSTM for time-series prediction
   - Multi-modal behavioral analysis
   - Personalized stress thresholds

2. **Enhanced AI Assistant**
   - Voice input/output
   - Natural language processing
   - Sentiment analysis

3. **Integrations**
   - Calendar sync (auto-detect work hours)
   - Screen time apps (auto-import data)
   - Sleep tracking apps

4. **Analytics**
   - Weekly/monthly reports
   - Downloadable PDFs
   - Stress pattern insights

5. **Social Features**
   - Anonymous community support
   - Shared wellness challenges
   - Group meditation sessions

---

## 📝 Documentation

- **[NEW_SYSTEM_GUIDE.md](NEW_SYSTEM_GUIDE.md)** - Complete system documentation
- **[CHATBOT_FEATURES.md](CHATBOT_FEATURES.md)** - AI chatbot features
- **[QUICKSTART.md](QUICKSTART.md)** - Quick start guide
- **[API_INTEGRATION_GUIDE.md](API_INTEGRATION_GUIDE.md)** - Backend integration

---

## 🤝 Contributing

This is a final year engineering project. For academic collaboration:
1. Fork the repository
2. Create a feature branch
3. Submit a pull request

---

## 📄 License

Educational Use - Final Year Engineering Project © 2026

---

## 🆘 Support

For issues or questions:
- Check documentation files
- Review console logs (F12)
- Verify Node.js 18+
- Ensure all dependencies installed

---

## 🎯 Key Achievements

✅ Modern, responsive UI design  
✅ AI-powered stress calculation  
✅ Real-time chatbot integration  
✅ Behavioral pattern analysis  
✅ Privacy-focused approach  
✅ Professional healthcare aesthetic  
✅ Smooth animations & transitions  
✅ Comprehensive documentation  

---

**Built with 💙 for better mental health through AI**

*Final Year Engineering Project - Behavioral Pattern-Based Stress Detection System*
